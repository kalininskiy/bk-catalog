Bolder Dash port for BK-0010-01, BK-0011(M)

Use ./release/bolde3.bin, copy it to Bin folder in emulator

To run on BK-0010:
from Basic type: MO <enter> M bolde3 <enter> S <enter>

To run on BK-0011M:
from Basic type: MO <enter> L bolde3 <enter> R6 / 1000 <enter> 1000G
