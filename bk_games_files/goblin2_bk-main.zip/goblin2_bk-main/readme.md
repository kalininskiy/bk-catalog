**Goblin Castle (BK0010/11M)**<br />
Sort of 'Lode Runner' style game. Inspired by original Goblin Castle for MS-0511 (UKNC).<br />
<br />
Release: [release/goblin2.bin](/release/goblin2.bin?raw=true) - binary file for BK emulators<br />
<br />
![Screenshot 1](/screenshots/goblin2_bk_1.png?raw=true)<br />
<br />
![Screenshot 2](/screenshots/goblin2_bk_2.png?raw=true)<br />
