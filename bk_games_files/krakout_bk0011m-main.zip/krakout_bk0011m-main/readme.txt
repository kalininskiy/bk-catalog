Krakout port for BK-0011(M)
Use /release/krakout.bin for launch in emulator
