// ----------------------------------------------
// cutting songs into parts not exceeding 16K
//
// JavaScript
// KUVO/CSI, 2026
// ----------------------------------------------

var fso = new ActiveXObject("Scripting.FileSystemObject");

var objStreamSource = new ActiveXObject("ADODB.Stream");
objStreamSource.Mode = 3;
objStreamSource.Type = 1; //bin

var objStreamDest   = new ActiveXObject("ADODB.Stream");
objStreamDest.Mode = 3;
objStreamDest.Type = 1; //bin

var folder = fso.GetFolder(fso.GetAbsolutePathName('.'));

files = new Enumerator(folder.Files);

for (;!files.atEnd();files.moveNext()) {
         
   var fso_file = files.item();

   var filename = fso_file.Name;

   if (filename.indexOf('.pt3')!=-1) {
      var song_fname = (filename.substring(filename.indexOf('_')+1));
      song_fname = folder.path + '\\' + song_fname.substring(0, song_fname.lastIndexOf('.'));

      objStreamSource.Open();
      objStreamSource.LoadFromFile(folder.path + '\\' + filename);
      objStreamSource.Position = 0;

      if (fso_file.Size > 16384) {
         writeDestinationFile(song_fname + '-1.ovl', 16384);
         writeDestinationFile(song_fname + '-2.ovl', fso_file.Size - 16384);
      }
      else {
         writeDestinationFile(song_fname + '.ovl', fso_file.Size);
      }

      objStreamSource.Close();
   }

}

objStreamSource = null;
objStreamDest = null;

function writeDestinationFile(fname, len) {
   objStreamDest.Open();
   objStreamDest.Write(objStreamSource.Read(len));
   objStreamDest.SaveToFile(fname, 2);
   objStreamDest.Close();
}