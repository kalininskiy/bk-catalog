/*-------------------------------------------------------------------------------
; CREATE TABLE OF SINE
;
; by VLADIMIR 'KUVO' KUTYAKOV ,CSI, SAMARA-CITY, 2021
;
; JavaScript
;-------------------------------------------------------------------------------
*/			


	var tsin = '';
	var strlen = 8;

	for (i=0; i<256; i+=4) {

		gval = (Math.round( (255*((Math.sin((2 * Math.PI * i) / 255) + 1) / 2) ) / 16. )).toString(8);
		tsin += gval + ',';
		strlen--;
		if (strlen==0){strlen=8; tsin+='\r\n';}
	}

	FSO = WScript.CreateObject('Scripting.FileSystemObject');
	TextStream = FSO.CreateTextFile('asin.txt');
	TextStream.Write('.byte ' + tsin);
	TextStream.Close();
