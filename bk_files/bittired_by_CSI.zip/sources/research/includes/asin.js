/*-------------------------------------------------------------------------------
; CREATE TABLE OF SINE FOR BK PROJECTS THATS ARE WRITTEN IN PDPy11
;
; by VLADIMIR 'KUVO' KUTYAKOV FROM CSI, SAMARA-CITY, 2021
;
; JavaScript
;-------------------------------------------------------------------------------
*/			


	var tsin = '';
	var strlen = 8;

	for (i=0; i<128; i++) {

		gval = (Math.round( 255 * ( (Math.sin((4 * Math.PI * i) / 127) + 1) / 2))).toString(8);
		tsin += gval + (i==127?'':',');
		strlen--;
		if (strlen==0){strlen=8; tsin+='\r\n';}
	}

	FSO = WScript.CreateObject('Scripting.FileSystemObject');
	TextStream = FSO.CreateTextFile('asin.txt');
	TextStream.Write('.byte ' + tsin);
	TextStream.Close();


	var tcos = '';
	var strlen = 8;

	for (i=0; i<128; i++) {

		gval = (Math.round( 255 * ( (Math.cos((4 * Math.PI * i) / 127) + 1) / 2))).toString(8);
		tcos += gval + (i==127?'':',');
		strlen--;
		if (strlen==0){strlen=8; tcos+='\r\n';}
	}

	FSO = WScript.CreateObject('Scripting.FileSystemObject');
	TextStream = FSO.CreateTextFile('acos.txt');
	TextStream.Write('.byte ' + tcos);
	TextStream.Close();

