FSO = WScript.CreateObject('Scripting.FileSystemObject');
File = FSO.GetFile('asciiman_orig.txt');
TextStream = File.OpenAsTextStream(1);
Result = '';
for(;!TextStream.AtEndOfStream;) {
    Result = Result + TextStream.ReadLine();
}
TextStream.Close();
aResult = Result.split(',');

//WScript.echo(aResult);

sResult = '.BYTE ';
strLen = 0;

for (i=0;i<aResult.length;i++) {
	gElement = aResult[i];
	if(isNumeric(gElement)) {

			if (parseInt(gElement,10)>255)WScript.echo(gElement + ',' + aResult[i+1]);
		sResult += gElement + '.,';
		strLen += 4;
	}
	else {
		for (j=0;j<gElement.length;j++) {
			gCode = gElement.charCodeAt(j);
			if (gCode>255)WScript.echo(gElement);
			sResult += gCode + '.,';
			strLen += 5;
		}
	}
	if(strLen>80) {strLen = 0; sResult += '\r\n'}

}

sResult += '0.';

//WScript.echo(sResult);

TextStream = FSO.CreateTextFile('asciiman_res.txt');
TextStream.Write(sResult);
TextStream.Close();


function isNumeric(gValue) {
	if ('0123456789'.indexOf(gValue.substr(0,1))!=-1) return true;
	else return false;
}