// LimitDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Sprites.h"
#include "LimitDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLimitDialog dialog


CLimitDialog::CLimitDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CLimitDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLimitDialog)
	m_Limit_Value = 0;
	//}}AFX_DATA_INIT
}


void CLimitDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLimitDialog)
	DDX_Text(pDX, IDC_EDIT1, m_Limit_Value);
	DDV_MinMaxByte(pDX, m_Limit_Value, 0, 128);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLimitDialog, CDialog)
	//{{AFX_MSG_MAP(CLimitDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLimitDialog message handlers
