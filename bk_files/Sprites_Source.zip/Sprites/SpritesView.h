// SpritesView.h : interface of the CSpritesView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPRITESVIEW_H__F7ABA9BE_EDB8_40E2_8C67_174489A35CC0__INCLUDED_)
#define AFX_SPRITESVIEW_H__F7ABA9BE_EDB8_40E2_8C67_174489A35CC0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define HbtMax 64 //������������ ������ "������" � ������ = 64
#include "SmartRect.h"

class CSpritesView : public CScrollView
{
protected: // create from serialization only
	CSpritesView();
	DECLARE_DYNCREATE(CSpritesView)

// Attributes
public:
	CSpritesDoc* GetDocument();

// Operations
public:

protected:
	CBrush m_BrushBlack;
	CBrush m_BrushWhite;
	CBrush m_BrushGray;
	CPen m_PenBlack;
	CPen m_PenGray;
	CPen m_PenWhite;
	CPen m_PenRed;
	CPen m_PenGreen;
	CPen m_PenBlue;
	CBrush* m_pBrushOld;
	CPen* m_pPenOld;

	BYTE m_scaleX;
	BYTE m_scaleY;
	short m_nQbit;
	BYTE m_nQbyte;
	CRect m_RAMrect;

	CSmartRect smRect[HbtMax];
	BYTE m_nLimit;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpritesView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual void OnInitialUpdate();
	char m_nColNum;
	BOOL m_bLimitAuto;
	BOOL m_bColorMode;
//	afx_msg void OnUpdateScale(CCmdUI* pCmdUI);
	afx_msg void OnScale(UINT nID);
	afx_msg void OnWidth(UINT nID);
	afx_msg void OnWidthEx(UINT nID);

	virtual ~CSpritesView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
void CSpritesView::WriteMyInfo2(short nAddr);
void DrawBytes(CDC *pDC, unsigned int Bt, short x, short y,short Qbit);
void DrawColorBytes(CDC *pDC, unsigned int Bt, short x, short y, short Qbit);
void itostr(CString *pszSTR,int nNum,char nRadix);

// Generated message map functions
protected:
	char m_nBkGr;
	BOOL m_bAddr;
	BOOL m_bAddrOct;
	BOOL m_bAddrDec;
	BOOL m_bAddrHex;
	BOOL m_bWrd;
	BOOL m_bWrdOct;
	BOOL m_bWrdDec;
	BOOL m_bWrdHex;
	BOOL m_bByte;
	BOOL m_bByteOct;
	BOOL m_bByteDec;
	BOOL m_bByteHex;
	CString m_strXYW;
	//{{AFX_MSG(CSpritesView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnColormode();
	afx_msg void OnUpdateColormode(CCmdUI* pCmdUI);
	afx_msg void OnLimitAuto();
	afx_msg void OnUpdateLimitAuto(CCmdUI* pCmdUI);
	afx_msg void OnLimitNone();
	afx_msg void OnUpdateLimitNone(CCmdUI* pCmdUI);
	afx_msg void OnLimitSet();
	afx_msg void OnWidthEx2();
	afx_msg void OnViewAddressformat();
	//}}AFX_MSG
	afx_msg void OnUpdateXYW(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SpritesView.cpp
inline CSpritesDoc* CSpritesView::GetDocument()
   { return (CSpritesDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPRITESVIEW_H__F7ABA9BE_EDB8_40E2_8C67_174489A35CC0__INCLUDED_)
