//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Sprites.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DIALOGBAR                   103
#define IDR_MAINFRAME                   128
#define IDR_SPRITETYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDC_EDIT1                       1000
#define IDC_ADDR_OCT                    1001
#define IDC_ADDR_DEC                    1002
#define IDC_ADDR_HEX                    1003
#define IDC_ADDR                        1004
#define IDC_WORD_OCT                    1005
#define IDC_WORD_DEC                    1006
#define IDC_WORD_HEX                    1007
#define IDC_WORD                        1008
#define IDC_BYTE_OCT                    1009
#define IDC_BYTE_DEC                    1010
#define IDC_BYTE_HEX                    1011
#define IDC_BYTE                        1012
#define ID_BUTTON32771                  32771
#define ID_YMINUS                       32772
#define ID_XPLUS                        32773
#define ID_XMINUS                       32774
#define ID_YPLUS                        32775
#define ID_BUTTON32776                  32776
#define ID_BUTTON32777                  32777
#define ID_BUTTON32778                  32778
#define ID_BUTTON32779                  32779
#define ID_BUTTON32780                  32780
#define ID_BUTTON32781                  32781
#define ID_BUTTON32782                  32782
#define ID_BUTTON32783                  32783
#define ID_COLORMODE                    32784
#define ID_LIMIT                        32785
#define ID_LIMIT_AUTO                   32786
#define ID_LIMIT_NONE                   32787
#define ID_LIMITS_SET                   32788
#define ID_LIMIT_SET                    32789
#define ID_BUTTON32790                  32790
#define ID_BUTTON32791                  32791
#define ID_BUTTON32792                  32792
#define ID_LIMITS_WIDTH                 32793
#define ID_WIDTH                        32794
#define ID_ADDRESS                      32795
#define ID_VIEW_ADDRESSFORMAT           32796
#define ID_HELP_SPRITES                 32797
#define ID_INDICATOR_XYW                59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
