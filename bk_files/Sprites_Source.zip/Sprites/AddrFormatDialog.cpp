// AddrFormatDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Sprites.h"
#include "AddrFormatDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddrFormatDialog dialog


CAddrFormatDialog::CAddrFormatDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CAddrFormatDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddrFormatDialog)
	m_bAddr = FALSE;
	m_bAddrDec = FALSE;
	m_bAddrHex = FALSE;
	m_bAddrOct = FALSE;
	m_bByte = FALSE;
	m_bByteDec = FALSE;
	m_bByteHex = FALSE;
	m_bByteOct = FALSE;
	m_bWord = FALSE;
	m_bWordDec = FALSE;
	m_bWordHex = FALSE;
	m_bWordOct = FALSE;
	//}}AFX_DATA_INIT
}


void CAddrFormatDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddrFormatDialog)
	DDX_Check(pDX, IDC_ADDR, m_bAddr);
	DDX_Check(pDX, IDC_ADDR_DEC, m_bAddrDec);
	DDX_Check(pDX, IDC_ADDR_HEX, m_bAddrHex);
	DDX_Check(pDX, IDC_ADDR_OCT, m_bAddrOct);
	DDX_Check(pDX, IDC_BYTE, m_bByte);
	DDX_Check(pDX, IDC_BYTE_DEC, m_bByteDec);
	DDX_Check(pDX, IDC_BYTE_HEX, m_bByteHex);
	DDX_Check(pDX, IDC_BYTE_OCT, m_bByteOct);
	DDX_Check(pDX, IDC_WORD, m_bWord);
	DDX_Check(pDX, IDC_WORD_DEC, m_bWordDec);
	DDX_Check(pDX, IDC_WORD_HEX, m_bWordHex);
	DDX_Check(pDX, IDC_WORD_OCT, m_bWordOct);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddrFormatDialog, CDialog)
	//{{AFX_MSG_MAP(CAddrFormatDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddrFormatDialog message handlers
