// SpritesView.cpp : implementation of the CSpritesView class
//

#include "stdafx.h"
#include "Sprites.h"

#include "SpritesDoc.h"
#include "SpritesView.h"
#include "SmartRect.h"
#include "LimitDialog.h"
#include "MainFrm.h"
#include "WidthDialog.h"
#include "AddrFormatDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define INITX 0
#define INITY 0
#define HbtMax 64
#define Vbt 256

/////////////////////////////////////////////////////////////////////////////
// CSpritesView

IMPLEMENT_DYNCREATE(CSpritesView, CScrollView)

BEGIN_MESSAGE_MAP(CSpritesView, CScrollView)
	//{{AFX_MSG_MAP(CSpritesView)
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_COLORMODE, OnColormode)
	ON_UPDATE_COMMAND_UI(ID_COLORMODE, OnUpdateColormode)
	ON_COMMAND(ID_LIMIT_AUTO, OnLimitAuto)
	ON_UPDATE_COMMAND_UI(ID_LIMIT_AUTO, OnUpdateLimitAuto)
	ON_COMMAND(ID_LIMIT_NONE, OnLimitNone)
	ON_UPDATE_COMMAND_UI(ID_LIMIT_NONE, OnUpdateLimitNone)
	ON_COMMAND(ID_LIMIT_SET, OnLimitSet)
	ON_COMMAND(ID_WIDTH, OnWidthEx2)
	ON_COMMAND(ID_VIEW_ADDRESSFORMAT, OnViewAddressformat)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_COMMAND_RANGE(ID_YMINUS,ID_YPLUS,OnScale)
	ON_COMMAND_RANGE(ID_BUTTON32776,ID_BUTTON32783,OnWidth)
	ON_COMMAND_RANGE(ID_BUTTON32790,ID_BUTTON32792,OnWidthEx)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_XYW,OnUpdateXYW)
//	ON_UPDATE_COMMAND_UI_RANGE(ID_YMINUS,ID_YPLUS,OnUpdateScale)
//	ON_UPDATE_COMMAND_UI_RANGE(ID_BUTTON32776,ID_BUTTON32779,OnUpdateWidth)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpritesView construction/destruction

CSpritesView::CSpritesView()
{
	// TODO: add construction code here
	m_BrushGray.CreateSolidBrush(0xA0A0A4);
	m_BrushBlack.CreateSolidBrush(0x000000);
	m_BrushWhite.CreateSolidBrush(0xFFFFFF);
	m_PenGray.CreatePen(PS_SOLID,0,(COLORREF)0xA0A0A4);
	m_PenBlack.CreatePen(PS_SOLID,0,(COLORREF)0x000000);
	m_PenWhite.CreatePen(PS_SOLID,0,(COLORREF)0xFFFFFF);
	m_PenRed.CreatePen(PS_SOLID,0,(COLORREF)0xFF);
	m_PenGreen.CreatePen(PS_SOLID,0,(COLORREF)0xFF00);
	m_PenBlue.CreatePen(PS_SOLID,0,(COLORREF)0xFF0000);
//	m_PenGrid.CreatePen(PS_SOLID,0,(COLORREF)0x181818);
//	m_scaleX=2;
//	m_scaleY=3;
//	m_nQbyte=1;
//	m_nLimit=1;
//	m_bColorMode=FALSE;
//	m_bLimitAuto=TRUE;
	m_strXYW="X=0  Y=0  Width=00";

			//Load Settings from .ini file
	TCHAR szCurDir[300];
	DWORD nCurDir=GetCurrentDirectory(256,szCurDir);
	szCurDir[nCurDir++]='\\';
	const char* ptr=AfxGetApp()->m_pszProfileName;
	while(*ptr)szCurDir[nCurDir++]=*ptr++;
	sprintf(&(szCurDir[nCurDir]),".ini\0");
	m_bAddr=GetPrivateProfileInt("Settings","bAddr",1,&szCurDir[0]);
	m_bAddrOct=GetPrivateProfileInt("Settings","bAddrOct",1,&szCurDir[0]);
	m_bAddrDec=GetPrivateProfileInt("Settings","bAddrDec",1,&szCurDir[0]);
	m_bAddrHex=GetPrivateProfileInt("Settings","bAddrHex",0,&szCurDir[0]);
	m_bWrd=GetPrivateProfileInt("Settings","bWord",1,&szCurDir[0]);
	m_bWrdOct=GetPrivateProfileInt("Settings","bWordOct",1,&szCurDir[0]);
	m_bWrdDec=GetPrivateProfileInt("Settings","bWordDec",1,&szCurDir[0]);
	m_bWrdHex=GetPrivateProfileInt("Settings","bWordHex",0,&szCurDir[0]);
	m_bByte=GetPrivateProfileInt("Settings","bByte",1,&szCurDir[0]);
	m_bByteOct=GetPrivateProfileInt("Settings","bByteOct",1,&szCurDir[0]);
	m_bByteDec=GetPrivateProfileInt("Settings","bByteDec",1,&szCurDir[0]);
	m_bByteHex=GetPrivateProfileInt("Settings","bByteHex",0,&szCurDir[0]);
	m_scaleX=GetPrivateProfileInt("Settings","scaleX",2,&szCurDir[0]);
	m_scaleY=GetPrivateProfileInt("Settings","scaleY",3,&szCurDir[0]);
	m_nQbyte=GetPrivateProfileInt("Settings","Width",1,&szCurDir[0]);
	m_nQbit=m_nQbyte*8;
	m_bLimitAuto=GetPrivateProfileInt("Settings","bLimitAuto",1,&szCurDir[0]);
	m_nLimit=GetPrivateProfileInt("Settings","LimitSize",1,&szCurDir[0]);
//	m_nBkGr=GetPrivateProfileInt("Settings","Background",1,&szCurDir[0]);
	m_bColorMode=GetPrivateProfileInt("Settings","bColorMode",0,&szCurDir[0]);
}

CSpritesView::~CSpritesView()
{
}

BOOL CSpritesView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSpritesView drawing

void CSpritesView::OnDraw(CDC* pDC)
{
	CSpritesDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
//	m_RAMrect=CRect(INITX,INITY,INITX+HbtMax*8*m_scaleX+64,INITY+Vbt*m_scaleY);

	//����.������ ������ � ������ ����� �� ������ ������� � ������
//�������� ���-�� �������. ���� ������� �� 0, ����� ����������� ������ ���������������. ��� ����� ���� ����� ������ ������.
	m_nColNum=HbtMax/m_nQbyte;

	int nBufSize=pDoc->m_nQbytesRead;
	short nHeight=nBufSize/m_nColNum/m_nQbyte;
	if(nBufSize>(m_nColNum*m_nQbyte*nHeight))nHeight++;
	//���-�� ������ � �������
	short nQbyteCol=nHeight*m_nQbyte;
	//������������
	nHeight*=m_scaleY;
	short nWidth=m_nQbit*m_scaleX;
	//����
	if(m_bColorMode)nWidth>>=1;
	//�������
	if(m_bLimitAuto){if(m_nQbyte==HbtMax)m_nLimit=0; else m_nLimit=m_nQbyte;}

	m_RAMrect=CRect(INITX,INITY,INITX+(m_nColNum*m_nQbit*m_scaleX/((char)(m_bColorMode+1))+m_nLimit*(m_nColNum-1)),INITY+nHeight);
	
	m_pBrushOld=pDC->GetCurrentBrush();
	m_pPenOld=pDC->GetCurrentPen();
	if(m_nLimit)
	{
		pDC->SelectObject(m_BrushGray);
		pDC->SelectObject(m_PenGray);
//		m_RAMrect.bottom+=10;
		pDC->Rectangle(&m_RAMrect);
//		m_RAMrect.bottom-=10;
//		pDC->Rectangle(INITX-40,INITY,INITX,300);
	}
	SetScrollSizes(MM_TEXT,CSize(m_RAMrect.right,m_RAMrect.bottom));

	pDC->SelectObject(&m_BrushBlack);
	pDC->SelectObject(&m_PenBlack);
	
	for(char i=0;i<m_nColNum;i++)
	{
		smRect[i].m_ScrRect=CRect(INITX+i*(nWidth+m_nLimit),m_RAMrect.top,
			INITX+i*(nWidth+m_nLimit)+nWidth,m_RAMrect.bottom);
		smRect[i].m_BegAddr=nQbyteCol*i;
		smRect[i].m_EndAddr=smRect[i].m_BegAddr+nQbyteCol;
		pDC->Rectangle(&(smRect[i].m_ScrRect));
	}
	
	pDC->SelectObject(&m_PenWhite);


	UINT nParam; //���� ����� ������ 4 �����, ���� �� �������� ��� ������ ���
	short stepX=32*m_scaleX/(char)(m_bColorMode+1); //��� ������� � 4 ����� ��� ������� �������
	int nIndex; //����� �������� �������

	for(i=0;i<m_nColNum;i++)
	{
		int nIndex0=smRect[i].m_BegAddr; //��������� ����� �������
		short Xi=(short)smRect[i].m_ScrRect.left; //���������� � ������ ���� ������� 
		char n4=m_nQbyte/4; char n0=m_nQbyte%4;

		while(n4--) //���������� 4� �������� �������
		{
			nIndex=nIndex0;
			for(short j=(short)m_RAMrect.top; j<m_RAMrect.bottom; j+=m_scaleY)
				{
					for(int k=nIndex+3; k>=nIndex; k--) //������������ 4 ����� � ���������� �������
						{
							nParam<<=8;
							nParam|= pDoc->m_Buff[k];
						}

						if(m_bColorMode)DrawColorBytes(pDC,nParam, Xi , j, 32); //���������� 4 �����
						else DrawBytes(pDC,nParam, Xi , j, 32); //���������� 4 �����
//						DrawBytes(pDC,nParam, Xi , j, 32); //���������� 4 �����
						nIndex+=m_nQbyte;
				}
			Xi+=stepX;
			nIndex0+=4;
		}

		if(n0) //���������� 3 ����� � ������
		{
			char bit_num=n0<<3;
			nIndex=nIndex0;
			for(short j=(short)m_RAMrect.top; j<m_RAMrect.bottom; j+=m_scaleY)
				{
				nParam=0;//��� �� ����� �� �� ����� ��� ��������, ������� �������
					for(int k=nIndex+n0-1; k>=nIndex; k--) //������������ 4 ����� � ���������� �������
						{
							nParam<<=8;
							nParam|= pDoc->m_Buff[k];
						}
					if(m_bColorMode)DrawColorBytes(pDC,nParam, Xi , j, bit_num); //���������� ������ 4 ��.������
					else DrawBytes(pDC,nParam, Xi , j, bit_num); //���������� ������ 4� ������
//					DrawBytes(pDC,nParam, Xi , j, 32); //���������� 4 �����
					nIndex+=m_nQbyte;
				}
//			Xi+=stepX; //��� �� ����, ����������� 0 ��� 1 ���
//			nIndex0+=4;//�� �� �����

		}
	}

	pDC->SelectObject(m_pBrushOld);
	pDC->SelectObject(m_pPenOld);
}

/////////////////////////////////////////////////////////////////////////////
// CSpritesView printing

BOOL CSpritesView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSpritesView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSpritesView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSpritesView diagnostics

#ifdef _DEBUG
void CSpritesView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CSpritesView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CSpritesDoc* CSpritesView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSpritesDoc)));
	return (CSpritesDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSpritesView message handlers

void CSpritesView::DrawBytes(CDC *pDC, unsigned int Bt, short x, short y, short Qbit)
{
	char nLength=0;
	unsigned int tst=1;
	for(char i=0;i<Qbit+1;i++)
//	do
	{
		if(Bt & tst){nLength++;}
		else 
		{
			if(nLength)
			{
			nLength*=m_scaleX;
			short x0=x+i*m_scaleX;
			short x1=x0;
			x0-=nLength;
			x1--;
			short y1=y;
			for(char j=0;j<m_scaleY;j++)
			{
				pDC->MoveTo(x0,y1);
				pDC->LineTo(x1,y1++);
			}
			nLength=0;
			}
		}
		tst<<=1;
	}//���� for i
}

void CSpritesView::DrawColorBytes(CDC *pDC, unsigned int Bt, short x, short y, short Qbit)
{
	Qbit>>=1; char code=0; char pcode=0; char nLength=0;
	for(char i=0;i<Qbit+1;i++)
	{
		code= Bt & 3;

		if(code)
		{
			if(pcode)
			{
				if(pcode==code)
				{
					nLength++;
				}
				else //pcode!=code
				{
					//Draw pcode color
 					nLength*=m_scaleX;
 					short x0=x+i*m_scaleX;
 					short x1=x0;
 					x0-=nLength;
 					x1--;
					short y1=y;
					switch(pcode)
					{
					case 1:
						pDC->SelectObject(&m_PenBlue);
						break;
					case 2:
						pDC->SelectObject(&m_PenGreen);
						break;
					case 3:
						pDC->SelectObject(&m_PenRed);
						break;
					default:
						break;
					}
					for(char j=0;j<m_scaleY;j++)
					{
						pDC->MoveTo(x0,y1);
						pDC->LineTo(x1,y1++);
					}
					nLength=1;
				}
			}
			else //pcode=0
			{
				nLength++;
			}
		}
		else
		{
			if(pcode)
			{
				//Draw pcode color
				nLength*=m_scaleX;
				short x0=x+i*m_scaleX;
				short x1=x0;
				x0-=nLength;
				x1--;
				short y1=y;
				switch(pcode)
				{
				case 1:
					pDC->SelectObject(&m_PenBlue);
					break;
				case 2:
					pDC->SelectObject(&m_PenGreen);
					break;
				case 3:
					pDC->SelectObject(&m_PenRed);
					break;
				default:
					break;
				}
				for(char j=0;j<m_scaleY;j++)
				{
					pDC->MoveTo(x0,y1);
					pDC->LineTo(x1,y1++);
				}
				nLength=0;
			}
		}
 		pcode=code;
 		Bt>>=2;
	} // next i
}

void CSpritesView::OnScale(UINT nID)
{
	switch(nID)
	{
	case ID_XPLUS:
		if(m_scaleX<4)m_scaleX++;
		break;
	case ID_YPLUS:
		if(m_scaleY<4)m_scaleY++;
		break;
	case ID_YMINUS:
		if(m_scaleY>1)m_scaleY--;
		break;
	case ID_XMINUS:
		if(m_scaleX>1)m_scaleX--;
		break;
	default:
		break;
	}
	Invalidate();
}

void CSpritesView::OnWidth(UINT nID)
{
	switch(nID)
	{
	case ID_BUTTON32776:
		m_nQbit=8;
		break;
	case ID_BUTTON32777:
		m_nQbit=16;
		break;
	case ID_BUTTON32778:
		m_nQbit=24;
		break;
	case ID_BUTTON32779:
		m_nQbit=32;
		break;
	case ID_BUTTON32780://quad
		m_nQbit=64;
		break;
	case ID_BUTTON32781://16
		m_nQbit=128;
		break;
	case ID_BUTTON32782://32
		m_nQbit=256;
		break;
	case ID_BUTTON32783://64
		m_nQbit=512;
		break;
	default:
		break;
	}
	m_nQbyte=m_nQbit>>3;
//	CMainFrame* pMainWnd=(CMainFrame*)AfxGetMainWnd();
//	pMainWnd->SetButtonCaption(m_nQbyte);
	Invalidate();
}

void CSpritesView::OnWidthEx(UINT nID)
{
	switch(nID)
	{
	case ID_BUTTON32790:
		if(m_nQbit>8){m_nQbit-=8;Invalidate();}
		break;
	case ID_BUTTON32792:
		if(m_nQbit<HbtMax*8){m_nQbit+=8;Invalidate();}
		break;
	default:
		break;
	}
	m_nQbyte=m_nQbit>>3;
//	CMainFrame* pMainWnd=(CMainFrame*)AfxGetMainWnd();
//	pMainWnd->SetButtonCaption(m_nQbyte);
}

//void CSpritesView::OnUpdateScale(CCmdUI *pCmdUI)
//{
//
//}

//void CSpritesView::OnUpdateWidth(CCmdUI *pCmdUI)
//{
//for(int i=ID_BUTTON32776;i<ID_BUTTON32779;i++)
//{
//	pCmdUI->m_nID
//
//}

void CSpritesView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC aDC(this);//�������� �������� ����������
	OnPrepareDC(&aDC);//�������� ��������� ����� � ���������� �����������
	aDC.DPtoLP(&point);//������� �� ���������� ��������� � ����������	dc.DPtoLP(&point,1);
	if(PtInRect(&m_RAMrect,point))//���� �������� � �������������
	{
		for(char c=0;c<m_nColNum;c++)
		{
			if(PtInRect(&smRect[c].m_ScrRect,point))
			{
				short delta=(point.x-smRect[c].m_ScrRect.left)/m_scaleX*(char)(m_bColorMode+1);
				BOOL bdelta=(BOOL)delta&0x7;
				delta>>=3;
				short nAddr=smRect[c].m_BegAddr+(point.y-INITY)/m_scaleY*m_nQbyte+delta;
				WriteMyInfo2(nAddr);
				break;
			}
		}
	}
	CScrollView::OnLButtonDown(nFlags, point);
}

//DEL void CSpritesView::WriteMyInfo(CDC* pDC,short x,short y,char nCount,short nIndex,CSpritesDoc* pDoc)
//DEL {
//DEL 	TCHAR szBuffer2[20];
//DEL 	unsigned short word=0;
//DEL 	pDC->TextOut(x,y, "Words");
//DEL 	short y1=y+30+nCount*40;
//DEL 	pDC->TextOut(x,y1, "Bytes ");
//DEL 
//DEL 	for(char i=0;i<nCount;i++)
//DEL 	{
//DEL 	word=(short)(pDoc->m_Buff[nIndex+1]);
//DEL 	word<<=8;
//DEL 	word=word | (pDoc->m_Buff[nIndex]);
//DEL 	
//DEL 	pDC->TextOut(x,y+20, "Oct: ");
//DEL 	pDC->TextOut(x,y+40, "Dec: ");
//DEL 
//DEL 	ZeroMemory(&szBuffer2,sizeof(szBuffer2));
//DEL 	_itoa(word,&szBuffer2[0],8);
//DEL 	pDC->TextOut(x+45,y+20,&szBuffer2[0],6);
//DEL 	_itoa(word,&szBuffer2[0],10);
//DEL 	pDC->TextOut(x+45,y+40,&szBuffer2[0],6);
//DEL 
//DEL 	//bytes oct
//DEL 	pDC->TextOut(x,y1+20, "Oct: ");
//DEL 	pDC->TextOut(x,y1+40, "Dec: ");
//DEL 	ZeroMemory(&szBuffer2,sizeof(szBuffer2));
//DEL 	_itoa(pDoc->m_Buff[nIndex],&szBuffer2[0],8);
//DEL 	_itoa(pDoc->m_Buff[nIndex+1],&szBuffer2[10],8);
//DEL 	pDC->TextOut(x+40,y1+20,&szBuffer2[0],3);
//DEL 	pDC->TextOut(x+80,y1+20,&szBuffer2[10],3);
//DEL 
//DEL 	//bytes 10
//DEL 	ZeroMemory(&szBuffer2,sizeof(szBuffer2));
//DEL 	_itoa(pDoc->m_Buff[nIndex],&szBuffer2[0],10);
//DEL 	_itoa(pDoc->m_Buff[nIndex+1],&szBuffer2[10],10);
//DEL 	pDC->TextOut(x+40,y1+40,&szBuffer2[0],3);
//DEL 	pDC->TextOut(x+80,y1+40,&szBuffer2[10],3);
//DEL 
//DEL 
//DEL 	nIndex++;nIndex++;
//DEL 	y+=40;y1+=40;
//DEL 	}
//DEL 				
//DEL }

void CSpritesView::WriteMyInfo2(short nAddr)
{
	CMainFrame* pMainWnd=(CMainFrame*)AfxGetMainWnd();
	ASSERT_VALID(pMainWnd);
	CSpritesDoc* pDoc=GetDocument();
	ASSERT_VALID(pDoc);
	TCHAR szBuffer[10];
	pMainWnd->m_wndLogBar.m_strAddressBar.Empty();
	if(nAddr>=pDoc->m_nQbytesRead)
	{
		//�����, ���, OUTSIDE OF MEMORY ADDRESS= � �� �� ����
		pMainWnd->m_wndLogBar.m_strAddressBar="OUTSIDE OF MEMORY\r\n";
	}
	else
	{
		//�������� ����� �� ���� ������ �������� � �� ���������
		pMainWnd->m_wndLogBar.m_strAddressBar.Empty();
		if(m_bAddr)
		{
			pMainWnd->m_wndLogBar.m_strAddressBar+="ADDRESS:\r\n";
			if(m_bAddrOct)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Oct: ";
				_itoa(nAddr,&szBuffer[0],8);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
			if(m_bAddrDec)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Dec: ";
				_itoa(nAddr,&szBuffer[0],10);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
			if(m_bAddrHex)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Hex: 0x";
				_itoa(nAddr,&szBuffer[0],16);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
		}
		if(m_bWrd)
		{
			pMainWnd->m_wndLogBar.m_strAddressBar+="\r\nWORD:\r\n";
			unsigned short Wrd=pDoc->m_Buff[nAddr&0xFFFE]|(pDoc->m_Buff[nAddr|1]<<8);
			if(m_bWrdOct)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Oct: ";
				_itoa(Wrd,&szBuffer[0],8);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
			if(m_bWrdDec)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Dec: ";
				_itoa(Wrd,&szBuffer[0],10);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
			if(m_bWrdHex)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Hex: 0x";
				_itoa(Wrd,&szBuffer[0],16);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
		}
		if(m_bByte)
		{
			pMainWnd->m_wndLogBar.m_strAddressBar+="\r\nBYTE:\r\n";
			if(m_bByteOct)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Oct: ";
				_itoa(pDoc->m_Buff[nAddr],&szBuffer[0],8);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
			if(m_bByteDec)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Dec: ";
				_itoa(pDoc->m_Buff[nAddr],&szBuffer[0],10);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
			if(m_bByteHex)
			{
				pMainWnd->m_wndLogBar.m_strAddressBar+="Hex: 0x";
				_itoa(pDoc->m_Buff[nAddr],&szBuffer[0],16);
				pMainWnd->m_wndLogBar.m_strAddressBar+=&szBuffer[0];
				pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
			}
		}
	}
	pMainWnd->m_wndLogBar.m_strAddressBar+="\r\n";
	pMainWnd->m_wndLogBar.UpdateData(FALSE);
}

void CSpritesView::OnColormode() 
{
	// TODO: Add your command handler code here
	m_bColorMode=!m_bColorMode;
	Invalidate();
}

void CSpritesView::OnUpdateColormode(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bColorMode);
}

void CSpritesView::OnLimitAuto() 
{
	// TODO: Add your command handler code here
	if(!m_bLimitAuto)
	{
		m_bLimitAuto=TRUE;
		Invalidate();
	}
}

void CSpritesView::OnUpdateLimitAuto(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bLimitAuto);
}

void CSpritesView::OnLimitNone() 
{
	// TODO: Add your command handler code here
	if(m_nLimit){m_nLimit=0;Invalidate();}
	m_bLimitAuto=FALSE;
}

void CSpritesView::OnUpdateLimitNone(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(!m_nLimit);
}

void CSpritesView::OnLimitSet() 
{
	// TODO: Add your command handler code here
	CLimitDialog limitDlg;
	limitDlg.m_Limit_Value=m_nLimit;
	if(IDOK==limitDlg.DoModal() && m_nLimit!=limitDlg.m_Limit_Value)
	{
		m_nLimit=limitDlg.m_Limit_Value;
		m_bLimitAuto=FALSE;
		Invalidate();
	};
}

void CSpritesView::OnWidthEx2() 
{
	// TODO: Add your command handler code here
	CWidthDialog widthDlg;
	widthDlg.m_nWidth=m_nQbyte;
	if(IDOK==widthDlg.DoModal() && m_nQbyte!=widthDlg.m_nWidth)
	{
		m_nQbyte=widthDlg.m_nWidth;
		m_nQbit=m_nQbyte<<3;
		Invalidate();
	};	
}

void CSpritesView::OnUpdateXYW(CCmdUI* pCmdUI)
{
	m_strXYW.SetAt(2,m_scaleX+'0');
	m_strXYW.SetAt(7,m_scaleY+'0');
	m_strXYW.SetAt(16,m_nQbyte/10+'0');
	m_strXYW.SetAt(17,m_nQbyte%10+'0');
	pCmdUI->SetText(m_strXYW);
}

void CSpritesView::itostr(CString *pszSTR,int nNum,char nRadix)
{
	while(nNum)
	{
		
	}
}

void CSpritesView::OnViewAddressformat() 
{
	// TODO: Add your command handler code here
	CAddrFormatDialog AFdlg;
	AFdlg.m_bAddr=m_bAddr;
	AFdlg.m_bAddrDec=m_bAddrDec;
	AFdlg.m_bAddrHex=m_bAddrHex;
	AFdlg.m_bAddrOct=m_bAddrOct;
	
	AFdlg.m_bWord=m_bWrd;
	AFdlg.m_bWordOct=m_bWrdOct;
	AFdlg.m_bWordHex=m_bWrdHex;
	AFdlg.m_bWordDec=m_bWrdDec;

	AFdlg.m_bByte=m_bByte;
	AFdlg.m_bByteOct=m_bByteOct;
	AFdlg.m_bByteHex=m_bByteHex;
	AFdlg.m_bByteDec=m_bByteDec;

	if(IDOK==AFdlg.DoModal())
	{
		m_bAddr=AFdlg.m_bAddr;
		m_bAddrDec=AFdlg.m_bAddrDec;
		m_bAddrHex=AFdlg.m_bAddrHex;
		m_bAddrOct=AFdlg.m_bAddrOct;
		
		m_bWrd=AFdlg.m_bWord;
		m_bWrdOct=AFdlg.m_bWordOct;
		m_bWrdHex=AFdlg.m_bWordHex;
		m_bWrdDec=AFdlg.m_bWordDec;
		
		m_bByte=AFdlg.m_bByte;
		m_bByteOct=AFdlg.m_bByteOct;
		m_bByteHex=AFdlg.m_bByteHex;
		m_bByteDec=AFdlg.m_bByteDec;
	}
}

void CSpritesView::OnInitialUpdate()
{
	SetScrollSizes(MM_TEXT,CSize(HbtMax*8*3,256*3));
}
