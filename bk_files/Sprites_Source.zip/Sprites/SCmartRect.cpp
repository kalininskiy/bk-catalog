// SCmartRect.cpp: implementation of the SCmartRect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Sprites.h"
#include "SCmartRect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SCmartRect::SCmartRect()
{

}

SCmartRect::~SCmartRect()
{

}
