// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Sprites.h"
#include "LogBar.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_UPDATE_COMMAND_UI(ID_ADDRESS, OnUpdateAddress)
	ON_COMMAND(ID_ADDRESS, OnAddress)
	ON_COMMAND(ID_HELP_SPRITES, OnHelpSprites)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_XYW
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

//	������ ������ ������ � ���������
	for(short i=10;i<=17;i++)
	m_wndToolBar.SetButtonStyle(i,TBSTYLE_CHECKGROUP);

//	if(!m_wndLogBar.Create(this,IDD_DIALOGBAR,CBRS_ALIGN_LEFT| CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC,IDD_DIALOGBAR))
	if (!m_wndLogBar.Create(this,IDD_DIALOGBAR,CBRS_SIZE_DYNAMIC | CBRS_GRIPPER | CBRS_ALIGN_LEFT,IDD_DIALOGBAR))
	{
		TRACE0("Failed to create dialogbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);


//	m_wndLogBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
//	CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_wndLogBar.SetWindowText("Address Bar");
	m_wndLogBar.EnableDocking(CBRS_ALIGN_LEFT|CBRS_ALIGN_RIGHT);
	DockControlBar(&m_wndLogBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


//DEL void CMainFrame::SetButtonCaption(char m_nQbyte)
//DEL {
//DEL 	char szBuffer[3];
//DEL 	szBuffer[0]=(char)(m_nQbyte/10+'0');
//DEL 	szBuffer[1]=(char)(m_nQbyte%10+'0');
//DEL 	szBuffer[3]='\0';
//DEL m_wndToolBar.SetButtonText(26,&szBuffer[0]);
//DEL }

void CMainFrame::OnUpdateAddress(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_wndLogBar.IsWindowVisible());
}

void CMainFrame::OnAddress() 
{
	// TODO: Add your command handler code here
	ShowControlBar(&m_wndLogBar,!m_wndLogBar.IsWindowVisible(),0);	
}

void CMainFrame::WriteOnPane()
{
//	m_wndLogBar.m_string.Empty();
//	while(*txt){m_wndLogBar.m_string+=*txt++;}
	m_wndLogBar.UpdateData(FALSE);
}

void CMainFrame::OnHelpSprites() 
{
	// TODO: Add your command handler code here
	ShellExecute(NULL,"open","Sprites.chm", NULL,NULL,SW_SHOWNORMAL);		
}

void CMainFrame::OnEditCopy() 
{
	// TODO: Add your command handler code here
//	AfxMessageBox("test");
	short lng=m_wndLogBar.m_strAddressBar.GetLength();
	if(lng)
	{
		if ( !OpenClipboard() )
		{
			TRACE( _T("Cannot open the Clipboard") );
			return;
		}
	   // Remove the current Clipboard contents
		if( !EmptyClipboard() )
		{
			TRACE( _T("Cannot empty the Clipboard") );
			return;
		}
	   // Get the currently selected data
	   HGLOBAL hGlob = GlobalAlloc(GMEM_FIXED, 512);
	   char* hGlob2=(char*)hGlob;
	   for(short i=0;i<lng;i++)
	   {
		   *hGlob2++=m_wndLogBar.m_strAddressBar.GetAt(i);
	   }
	   *hGlob2++=0;
//	   strcpy_s((char*)hGlob, 512, "Current selection\r\n");
	   // For the appropriate data formats...
	   if ( ::SetClipboardData( CF_TEXT, hGlob ) == NULL )
	   {
		   CString msg;
		   msg.Format(_T("Unable to set Clipboard data, error: %d"), GetLastError());
		   TRACE( msg );
		   CloseClipboard();
		   GlobalFree(hGlob);
		   return;
	   }
	   CloseClipboard();

	}
	
}
