#if !defined(AFX_ADDRFORMATDIALOG_H__5316E6AD_F22F_4ABA_8ACF_476D211F6ADF__INCLUDED_)
#define AFX_ADDRFORMATDIALOG_H__5316E6AD_F22F_4ABA_8ACF_476D211F6ADF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddrFormatDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddrFormatDialog dialog

class CAddrFormatDialog : public CDialog
{
// Construction
public:
	CAddrFormatDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddrFormatDialog)
	enum { IDD = IDD_DIALOG3 };
	BOOL	m_bAddr;
	BOOL	m_bAddrDec;
	BOOL	m_bAddrHex;
	BOOL	m_bAddrOct;
	BOOL	m_bByte;
	BOOL	m_bByteDec;
	BOOL	m_bByteHex;
	BOOL	m_bByteOct;
	BOOL	m_bWord;
	BOOL	m_bWordDec;
	BOOL	m_bWordHex;
	BOOL	m_bWordOct;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddrFormatDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddrFormatDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDRFORMATDIALOG_H__5316E6AD_F22F_4ABA_8ACF_476D211F6ADF__INCLUDED_)
