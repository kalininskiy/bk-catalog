// WidthDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Sprites.h"
#include "WidthDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWidthDialog dialog


CWidthDialog::CWidthDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CWidthDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWidthDialog)
	m_nWidth = 0;
	//}}AFX_DATA_INIT
}


void CWidthDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWidthDialog)
	DDX_Text(pDX, IDC_EDIT1, m_nWidth);
	DDV_MinMaxByte(pDX, m_nWidth, 1, 64);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWidthDialog, CDialog)
	//{{AFX_MSG_MAP(CWidthDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWidthDialog message handlers
