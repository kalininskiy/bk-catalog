// SmartRect.h: interface for the CSmartRect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMARTRECT_H__3D331B18_7F49_465A_95F0_655D679F04E1__INCLUDED_)
#define AFX_SMARTRECT_H__3D331B18_7F49_465A_95F0_655D679F04E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSmartRect  
{
	//attributes
public:
	CRect m_ScrRect;
	short m_BegAddr;
	short m_EndAddr;
//	BYTE m_nQbyte;

	//implementation
public:
	CSmartRect();
	virtual ~CSmartRect();

};

#endif // !defined(AFX_SMARTRECT_H__3D331B18_7F49_465A_95F0_655D679F04E1__INCLUDED_)
