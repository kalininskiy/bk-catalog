#if !defined(AFX_LOGBAR2_H__40837D0B_043E_4F34_8769_FDF91B1E80EE__INCLUDED_)
#define AFX_LOGBAR2_H__40837D0B_043E_4F34_8769_FDF91B1E80EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LogBar2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLogBar2 dialog

class CLogBar2 : public CDialog
{
// Construction
public:
	CLogBar2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLogBar2)
	enum { IDD = IDD_DIALOGBAR };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogBar2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLogBar2)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGBAR2_H__40837D0B_043E_4F34_8769_FDF91B1E80EE__INCLUDED_)
