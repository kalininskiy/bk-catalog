// SmartRect.cpp: implementation of the CSmartRect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Sprites.h"
#include "SmartRect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSmartRect::CSmartRect()
{

}

CSmartRect::~CSmartRect()
{

}
