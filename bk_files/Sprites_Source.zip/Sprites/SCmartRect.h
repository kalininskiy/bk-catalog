// SCmartRect.h: interface for the SCmartRect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCMARTRECT_H__62B3FAF3_67C8_48EF_8666_CC16D12F1C96__INCLUDED_)
#define AFX_SCMARTRECT_H__62B3FAF3_67C8_48EF_8666_CC16D12F1C96__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class SCmartRect  
{
	//attributes
public:
	CRect m_rect;
	short m_BegAddr;
	short m_EndAddr;
	BYTE m_nQbyte;

	//implementation
public:
	SCmartRect();
	virtual ~SCmartRect();

};

#endif // !defined(AFX_SCMARTRECT_H__62B3FAF3_67C8_48EF_8666_CC16D12F1C96__INCLUDED_)
