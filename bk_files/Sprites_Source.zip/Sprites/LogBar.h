#if !defined(AFX_LOGBAR_H__3DF298E5_FC2E_4BAE_AB86_6BB002DEF3A4__INCLUDED_)
#define AFX_LOGBAR_H__3DF298E5_FC2E_4BAE_AB86_6BB002DEF3A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LogBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLogBar dialog

class CLogBar : public CDialogBar
{
// Construction
public:
	CLogBar();   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLogBar)
	enum { IDD = IDD_DIALOGBAR };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	CString m_strAddressBar;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogBar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	afx_msg LONG OnInitDialog ( UINT wParam, LONG lParam );
	// Generated message map functions
	//{{AFX_MSG(CLogBar)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGBAR_H__3DF298E5_FC2E_4BAE_AB86_6BB002DEF3A4__INCLUDED_)
