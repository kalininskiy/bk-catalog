// LogBar.cpp : implementation file
//

#include "stdafx.h"
#include "Sprites.h"
#include "LogBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogBar dialog


CLogBar::CLogBar()
{
	//{{AFX_DATA_INIT(CLogBar)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLogBar::DoDataExchange(CDataExchange* pDX)
{
	CDialogBar::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLogBar)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_EDIT1, m_strAddressBar);
	DDV_MaxChars(pDX,m_strAddressBar,512);
}


BEGIN_MESSAGE_MAP(CLogBar, CDialogBar)
	//{{AFX_MSG_MAP(CLogBar)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_INITDIALOG, OnInitDialog )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogBar message handlers

LONG CLogBar::OnInitDialog ( UINT wParam, LONG lParam)
{
	// <-- with these lines. -->
	
	BOOL bRet = HandleInitDialog(wParam, lParam);
	
	if (!UpdateData(FALSE))
	{
		TRACE0("Warning: UpdateData failed during dialog init.\n");
	}
	
	return bRet;
}