; =====================================================================
; 3D WIREFRAME SHIPS FROM ELITE - FOR BK-0011M
; Assembler: BKTurbo8
; (c) 2026 - Ivan "VDM" Kalininskiy <https://t.me/VanDamM>
; =====================================================================

        .LA     2000

START:
        CALL    @#150170
        MOV     #017400, @#177716
        ; Палитра № 4 для БК-0011М.
        MOV     #042000, @#177662

        ; Запрет прерываний клавиатуры для прямого опроса регистров
        BIS     #100, @#177660
        MOV     @#177662, R0        ; Сброс возможного остаточного кода

        ; Генерация таблицы четвертей квадратов для быстрого MUL8 (256 слов)
        MOV     #SQR_TAB, R0
        CLR     (R0)+
        CLR     R1
        MOV     #1, R2
INIT_SQR:
        MOV     R2, R3
        ASR     R3
        ADD     R3, R1
        MOV     R1, (R0)+
        INC     R2
        CMP     R2, #256.
        BLT     INIT_SQR

        ; Изначально показываем страницу 6, рисуем в странице 5.
        MOV     #040000, DRAW_BASE
        MOV     #100000, DISPLAY_VALUE

        ; Однократная очистка обеих страниц видеопамяти.
        MOV     #040000, R0
        MOV     #020000, R1
CLR_PAGE5:
        CLR     (R0)+
        SOB     R1, CLR_PAGE5

        MOV     #100000, R0
        MOV     #020000, R1
CLR_PAGE6:
        CLR     (R0)+
        SOB     R1, CLR_PAGE6

        ; Отрисовка кокпита в обе страницы видеопамяти.
        JSR     PC, INIT_COCKPIT

        MOV     #100000, @#177662

        ; -------------------------------------------------
        ; Аппаратный таймер БК-0011М для измерения FPS.
        ; -------------------------------------------------
        MOV     #100000, R0        ; или 0
        BIC     #040000, R0        ; гарантированно сбросить бит 14
        MOV     R0, @#177662

        MOV     #1, @#177712       ; Остановить таймер
        MOV     #177777, @#177706  ; Максимальная предустановка
        MOV     #22, @#177712      ; Непрерывный счёт + запуск

        ; Запомнить начальное значение счётчика.
        MOV     @#177710, PREV_TIMER

; Начало главного цикла
MAIN_LOOP:
        ; 1. Стереть старые рёбра на текущей странице
        JSR     PC, ERASE_PREVIOUS_FRAME

        ; 2. Очистить область счётчика FPS
        JSR     PC, CLEAR_FPS_AREA

        ; 3. Вычисление углов и выборка синусов/косинусов
        JSR     PC, CALC_ANGLES_TRIG

        ; 4. Отсечение обратных граней (не зависит от вершин!)
        JSR     PC, CALC_FACE_VIS

        ; 5. Формирование списка видимых рёбер и разметка активных вершин
        JSR     PC, BUILD_VISIBLE_EDGES

        ; 6. Трансформация и проекция ТОЛЬКО активных вершин (Vertex Culling)
        JSR     PC, TRANSFORM_ALL_VERTS

        ; 7. Отрисовка видимых рёбер (и сохранение координат для стирания)
        JSR     PC, DRAW_ALL_EDGES

        ; 8. Измерение времени кадра и расчёт FPS
        JSR     PC, UPDATE_FPS

        ; 9. Вывод двух цифр FPS
        JSR     PC, DRAW_FPS

        ; 10. Проверка таймера (10 сек) и клавиатуры для смены корабля
        JSR     PC, PROCESS_INPUT_TIMER

        ; 11. Переключение видеостраниц (double buffering)
        MOV     DRAW_BASE, R0
        CMP     #040000, R0
        BNE     DRAWED_PAGE6

        MOV     #100000, DRAW_BASE
        MOV     #042000, DISPLAY_VALUE
        BR      SHOW_FRAME

DRAWED_PAGE6:
        MOV     #040000, DRAW_BASE
        MOV     #142000, DISPLAY_VALUE

SHOW_FRAME:
        MOV     DISPLAY_VALUE, @#177662
        BR      MAIN_LOOP
; Конец главного цикла


; ---------------------------------------------------------------------
; CALC_ANGLES_TRIG
; Шаг углов вращения и подготовка SIN_Y, COS_Y, SIN_X, COS_X на кадр.
; ---------------------------------------------------------------------
CALC_ANGLES_TRIG:
        MOVB    ANGLE_Y, R0
        ADD     #4, R0
        MOVB    R0, ANGLE_Y
        BIC     #177400, R0
        MOVB    SIN_TAB(R0), SIN_Y
        ADD     #64., R0
        BIC     #177400, R0
        MOVB    SIN_TAB(R0), COS_Y

        MOVB    ANGLE_X, R0
        ADD     #3, R0
        MOVB    R0, ANGLE_X
        BIC     #177400, R0
        MOVB    SIN_TAB(R0), SIN_X
        ADD     #64., R0
        BIC     #177400, R0
        MOVB    SIN_TAB(R0), COS_X

        RTS     PC


; ---------------------------------------------------------------------
; ТРАНСФОРМАЦИЯ И ПРОЕКЦИЯ ВЕРШИН
; Оптимизация: предварительно вычисленные произведения координат.
;
; Таблицы строятся один раз за кадр в BUILD_PRODUCT_TABLES.
; В цикле вершин остаются только 2 вызова MUL8 на вершину:
; Z1*SIN_X и Z1*COS_X.
; ---------------------------------------------------------------------
TRANSFORM_ALL_VERTS:
        ; Подготовка таблицы произведений на текущий кадр.
        JSR     PC, BUILD_PRODUCT_TABLES

        MOV     CUR_VERTS, R5
        CLR     R3

VERT_LOOP:
        ; Пропуск невидимых вершин (Vertex Culling)
        TSTB    VERT_USED(R3)
        BNE     10$
        JMP     VERT_SKIP
10$:
        ; -------------------------------------------------
        ; Поворот вокруг Y:
        ; X1 = (X*cosY - Z*sinY) / 128
        ; Z1 = (X*sinY + Z*cosY) / 128
        ; -------------------------------------------------

        ; X * cosY — из таблицы
        MOVB    (R5), R4
        BIC     #177400, R4
        ASL     R4
        MOV     PROD_COSY(R4), R0
        MOV     R0, -(SP)

        ; Z * sinY — из таблицы
        MOVB    2(R5), R4
        BIC     #177400, R4
        ASL     R4
        MOV     PROD_SINY(R4), R0

        MOV     (SP)+, R1
        SUB     R0, R1
        MOV     R1, R0
        ; Инлайн DIV128
        ASL     R0
        SWAB    R0
        MOVB    R0, R0
        MOV     R0, TMP_X1

        ; X * sinY — из таблицы
        MOVB    (R5), R4
        BIC     #177400, R4
        ASL     R4
        MOV     PROD_SINY(R4), R0
        MOV     R0, -(SP)

        ; Z * cosY — из таблицы
        MOVB    2(R5), R4
        BIC     #177400, R4
        ASL     R4
        MOV     PROD_COSY(R4), R0

        ADD     (SP)+, R0
        ; Инлайн DIV128
        ASL     R0
        SWAB    R0
        MOVB    R0, R0
        MOV     R0, TMP_Z1

        ; -------------------------------------------------
        ; Поворот вокруг X:
        ; Y2 = (Y*cosX - Z1*sinX) / 128
        ; Z2 = (Y*sinX + Z1*cosX) / 128
        ; -------------------------------------------------

        ; Y * cosX — из таблицы
        MOVB    1(R5), R4
        BIC     #177400, R4
        ASL     R4
        MOV     PROD_COSX(R4), R0
        MOV     R0, -(SP)

        ; Z1 * sinX — динамическое произведение
        MOV     TMP_Z1, R1
        MOVB    SIN_X, R2
        JSR     PC, MUL8

        MOV     (SP)+, R1
        SUB     R0, R1
        MOV     R1, R0
        ; Инлайн DIV128
        ASL     R0
        SWAB    R0
        MOVB    R0, R0
        MOV     R0, TMP_Y2

        ; Y * sinX — из таблицы
        MOVB    1(R5), R4
        BIC     #177400, R4
        ASL     R4
        MOV     PROD_SINX(R4), R0
        MOV     R0, -(SP)

        ; Z1 * cosX — динамическое произведение
        MOV     TMP_Z1, R1
        MOVB    COS_X, R2
        JSR     PC, MUL8

        ADD     (SP)+, R0
        ; Инлайн DIV128
        ASL     R0
        SWAB    R0
        MOVB    R0, R0
        ADD     #220., R0
        MOV     R0, TMP_Z2

        ; -------------------------------------------------
        ; Перспективная проекция
        ; -------------------------------------------------
        CMP     R0, #16.
        BGT     1$
        MOV     #16., R0
        MOV     R0, TMP_Z2
1$:
        MOV     TMP_X1, R0
        CLR     -(SP)
        TST     R0
        BPL     2$
        NEG     R0
        INC     (SP)
2$:
        MOV     TMP_Z2, R1
        JSR     PC, DIV_Z256
        TST     (SP)+
        BEQ     3$
        NEG     R0
3$:
        ; Масштаб 75%: R0 = R0 - R0/4, затем смещение от центра X=128
        MOV     R0, R1
        ASR     R1
        ASR     R1
        SUB     R1, R0
        ADD     #128., R0

        BPL     4$
        CLR     R0
4$:
        CMP     R0, #255.
        BLOS    5$
        MOV     #255., R0
5$:
        MOVB    R0, PROJ_X(R3)

        MOV     TMP_Y2, R0
        CLR     -(SP)
        TST     R0
        BPL     6$
        NEG     R0
        INC     (SP)
6$:
        MOV     TMP_Z2, R1
        JSR     PC, DIV_Z256
        TST     (SP)+
        BEQ     7$
        NEG     R0
7$:
        ; Масштаб 75%: R0 = R0 - R0/4, затем смещение от центра Y=104
        MOV     R0, R1
        ASR     R1
        ASR     R1
        SUB     R1, R0
        MOV     #104., R1
        SUB     R0, R1

        BPL     8$
        CLR     R1
8$:
        CMP     R1, #255.
        BLOS     9$
        MOV     #255., R1
9$:
        MOVB    R1, PROJ_Y(R3)

VERT_SKIP:
        ADD     #3, R5
        INC     R3
        CMP     R3, CUR_NUM_VERTS
        BGE     98$
        JMP     VERT_LOOP
98$:
        RTS     PC


; ---------------------------------------------------------------------
; BUILD_PRODUCT_TABLES
;
; Заполнение таблиц произведений на текущий кадр для активной модели.
;
; PROD_SINY / PROD_COSY:
;   произведения координат X и Z на SIN_Y / COS_Y.
;
; PROD_SINX / PROD_COSX:
;   произведения исходной координаты Y на SIN_X / COS_X.
;
; Проходит по вершинам текущей модели и рассчитывает произведения.
; Индекс — беззнаковое значение байта координаты * 2.
; ---------------------------------------------------------------------
BUILD_PRODUCT_TABLES:
        MOV     CUR_VERTS, R5
        MOV     CUR_NUM_VERTS, PROD_CTR

BUILD_PROD_LOOP:
        ; --- X координата ---
        MOVB    (R5), R1
        MOV     R1, R4
        BIC     #177400, R4
        ASL     R4

        MOVB    SIN_Y, R2
        JSR     PC, MUL8
        MOV     R0, PROD_SINY(R4)

        MOVB    (R5), R1
        MOVB    COS_Y, R2
        JSR     PC, MUL8
        MOV     R0, PROD_COSY(R4)

        ; --- Z координата ---
        MOVB    2(R5), R1
        MOV     R1, R4
        BIC     #177400, R4
        ASL     R4

        MOVB    SIN_Y, R2
        JSR     PC, MUL8
        MOV     R0, PROD_SINY(R4)

        MOVB    2(R5), R1
        MOVB    COS_Y, R2
        JSR     PC, MUL8
        MOV     R0, PROD_COSY(R4)

        ; --- Y координата ---
        MOVB    1(R5), R1
        MOV     R1, R4
        BIC     #177400, R4
        ASL     R4

        MOVB    SIN_X, R2
        JSR     PC, MUL8
        MOV     R0, PROD_SINX(R4)

        MOVB    1(R5), R1
        MOVB    COS_X, R2
        JSR     PC, MUL8
        MOV     R0, PROD_COSX(R4)

        ADD     #3, R5
        DEC     PROD_CTR
        BNE     BUILD_PROD_LOOP

        RTS     PC


; ---------------------------------------------------------------------
; ОТСЕЧЕНИЕ ОБРАТНЫХ ГРАНЕЙ
;
; Для каждой грани преобразуем нормаль теми же поворотами, что
; используются для вершин.
;
; Камера находится со стороны отрицательного Z до переноса модели
; на глубину 220. Поэтому грань видима, если повёрнутая нормаль
; имеет отрицательную Z-компоненту.
;
; Вход: SIN_Y, COS_Y, SIN_X, COS_X
; Выход: FACE_FLAGS[i] = 1 для видимой грани, 0 для обратной.
;
; Нормали имеют формат NX, NY, NZ; шаг таблицы — 3 байта.
; Используются существующие MUL8 и DIV128.
; ---------------------------------------------------------------------
CALC_FACE_VIS:
        MOV     CUR_NORMALS, R5
        MOV     #FACE_FLAGS, R4
        MOV     CUR_NUM_FACES, FACE_CTR

FACE_VIS_LOOP:
        ; Z1 = (NX * SIN_Y + NZ * COS_Y) / 128

        MOVB    (R5), R1
        MOVB    SIN_Y, R2
        JSR     PC, MUL8
        MOV     R0, -(SP)

        MOVB    2(R5), R1
        MOVB    COS_Y, R2
        JSR     PC, MUL8
        ADD     (SP)+, R0
        ; Инлайн DIV128
        ASL     R0
        SWAB    R0
        MOVB    R0, R0
        MOV     R0, TMP_NZ1

        ; Z2 = (NY * SIN_X + Z1 * COS_X) / 128

        MOVB    1(R5), R1
        MOVB    SIN_X, R2
        JSR     PC, MUL8
        MOV     R0, -(SP)

        MOV     TMP_NZ1, R1
        MOVB    COS_X, R2
        JSR     PC, MUL8
        ADD     (SP)+, R0
        ; Инлайн DIV128
        ASL     R0
        SWAB    R0
        MOVB    R0, R0

        ; Отрицательная Z-компонента нормали означает,
        ; что поверхность обращена к камере.

        TST     R0
        BPL     FACE_IS_BACK

        MOVB    #1, (R4)+
        BR      FACE_VIS_NEXT

FACE_IS_BACK:
        CLRB    (R4)+

FACE_VIS_NEXT:
        ADD     #3, R5
        DEC     FACE_CTR
        BNE     FACE_VIS_LOOP

        RTS     PC


; ---------------------------------------------------------------------
; ФОРМИРОВАНИЕ СПИСКА ВИДИМЫХ РЁБЕР
;
; Вход:
;   EDGES       — исходная таблица рёбер, 4 байта на ребро
;   FACE_FLAGS  — флаги видимости 13 граней
;
; Выход:
;   VISIBLE_EDGES      — последовательность пар индексов вершин
;   VISIBLE_EDGE_COUNT — число отобранных рёбер
;
; Ребро включается, если видна хотя бы одна соседняя грань.
; Максимальный размер списка: 38 * 2 = 76 байт.
; ---------------------------------------------------------------------
BUILD_VISIBLE_EDGES:
        CLR     VISIBLE_EDGE_COUNT

        ; Очистить флаги активности 32 вершин (16 слов)
        MOV     #VERT_USED, R0
        MOV     #16., R1
1$:     CLR     (R0)+
        SOB     R1, 1$

        MOV     CUR_EDGES, R5
        MOV     #VISIBLE_EDGES, R3
        MOV     CUR_NUM_EDGES, EDGE_CTR

BUILD_EDGE_LOOP:
        ; Сохраняем индексы вершин ребра.
        MOVB    (R5)+, EDGE_V1
        MOVB    (R5)+, EDGE_V2

        ; Индекс первой грани.
        MOVB    (R5)+, R0
        BIC     #177400, R0

        ; Индекс второй грани.
        MOVB    (R5)+, R1
        BIC     #177400, R1

        ; Проверяем первую грань.
        TSTB    FACE_FLAGS(R0)
        BNE     BUILD_EDGE_VISIBLE

        ; Первая грань обратная.
        ; Проверяем вторую грань.
        TSTB    FACE_FLAGS(R1)
        BEQ     BUILD_EDGE_NEXT

BUILD_EDGE_VISIBLE:
        ; Добавляем два индекса вершин в список.
        MOVB    EDGE_V1, (R3)+
        MOVB    EDGE_V2, (R3)+
        INC     VISIBLE_EDGE_COUNT

        ; Отмечаем вершины как активные в текущем кадре
        MOVB    EDGE_V1, R0
        BIC     #177400, R0
        MOVB    #1, VERT_USED(R0)
        MOVB    EDGE_V2, R0
        BIC     #177400, R0
        MOVB    #1, VERT_USED(R0)

BUILD_EDGE_NEXT:
        DEC     EDGE_CTR
        BNE     BUILD_EDGE_LOOP

        RTS     PC


; ---------------------------------------------------------------------
; ERASE_PREVIOUS_FRAME
;
; Стирает рёбра предыдущего кадра на текущей странице.
; У каждой страницы собственные сохранённые координаты и рёбра.
;
; Использует существующий DRAW_ALL_EDGES и BRESENHAM.
; ---------------------------------------------------------------------
ERASE_PREVIOUS_FRAME:
        MOV     DRAW_BASE, R0
        CMP     #040000, R0
        BNE     ERASE_DIRECT_PAGE6

        ; Страница 5: список координат концов старых рёбер.
        MOV     #OLD5_LINES, R5
        MOV     OLD5_COUNT, EDGE_CTR
        BR      ERASE_DIRECT_START

ERASE_DIRECT_PAGE6:
        ; Страница 6.
        MOV     #OLD6_LINES, R5
        MOV     OLD6_COUNT, EDGE_CTR

ERASE_DIRECT_START:
        ; На первой итерации после запуска старых рёбер ещё нет.
        TST     EDGE_CTR
        BEQ     ERASE_DIRECT_DONE

        MOV     #1, ERASE_MODE

ERASE_DIRECT_LOOP:
        ; Каждая запись: X0, Y0, X1, Y1.
        MOVB    (R5)+, R0
        BIC     #177400, R0

        MOVB    (R5)+, R1
        BIC     #177400, R1

        MOVB    (R5)+, R2
        BIC     #177400, R2

        MOVB    (R5)+, R3
        BIC     #177400, R3

        ; Стереть линию по сохранённым координатам.
        JSR     PC, BRESENHAM

        DEC     EDGE_CTR
        BNE     ERASE_DIRECT_LOOP

ERASE_DIRECT_DONE:
        CLR     ERASE_MODE
        RTS     PC


; ---------------------------------------------------------------------
; CLEAR_FPS_AREA
;
; Очищает только прямоугольник 16x8 пикселей в правом верхнем углу.
; 4 байта на строку, 8 строк.
; Выполняется после стирания старых рёбер и перед рисованием новых.
; ---------------------------------------------------------------------
CLEAR_FPS_AREA:
        ; Смещение 186. = строка Y=2, X=224 (байт 56), не задевает рамку экрана
        MOV     DRAW_BASE, R0
        ADD     #186., R0
        MOV     #8., R2

CLEAR_FPS_ROW:
        CLR     (R0)
        CLR     2(R0)
        ADD     #64., R0
        SOB     R2, CLEAR_FPS_ROW

        RTS     PC


; ---------------------------------------------------------------------
; ОТРИСОВКА ПРЕДВАРИТЕЛЬНО ОТОБРАННЫХ РЁБЕР
; И ОДНОВРЕМЕННОЕ СОХРАНЕНИЕ ДЛЯ СТИРАНИЯ
;
; Вход:
;   VISIBLE_EDGES      — пары индексов вершин
;   VISIBLE_EDGE_COUNT — число рёбер
;   PROJ_X, PROJ_Y     — координаты после проекции
; ---------------------------------------------------------------------
DRAW_ALL_EDGES:
        ; Подготовка буфера стирания для текущей страницы
        MOV     DRAW_BASE, R0
        CMP     #040000, R0
        BNE     1$
        MOV     #OLD5_LINES, OLD_PTR
        MOV     VISIBLE_EDGE_COUNT, OLD5_COUNT
        BR      2$
1$:
        MOV     #OLD6_LINES, OLD_PTR
        MOV     VISIBLE_EDGE_COUNT, OLD6_COUNT
2$:
        MOV     #VISIBLE_EDGES, R5
        MOV     VISIBLE_EDGE_COUNT, EDGE_CTR

        ; Если видимых рёбер нет, завершаем процедуру.
        TST     EDGE_CTR
        BEQ     DRAW_EDGES_DONE

DRAW_EDGE_LOOP:
        ; Координаты первой вершины.
        MOVB    (R5)+, R4
        BIC     #177400, R4

        MOVB    PROJ_X(R4), R0
        BIC     #177400, R0

        MOVB    PROJ_Y(R4), R1
        BIC     #177400, R1

        ; Координаты второй вершины.
        MOVB    (R5)+, R4
        BIC     #177400, R4

        MOVB    PROJ_X(R4), R2
        BIC     #177400, R2

        MOVB    PROJ_Y(R4), R3
        BIC     #177400, R3

        ; Сохраняем координаты сразу в буфер стирания
        MOV     OLD_PTR, R4
        MOVB    R0, (R4)+
        MOVB    R1, (R4)+
        MOVB    R2, (R4)+
        MOVB    R3, (R4)+
        MOV     R4, OLD_PTR

        ; Рисуем ребро.
        JSR     PC, BRESENHAM

        DEC     EDGE_CTR
        BNE     DRAW_EDGE_LOOP

DRAW_EDGES_DONE:
        RTS     PC


; ---------------------------------------------------------------------
; BRESENHAM — отдельные циклы рисования и стирания.
;
; Вход: R0=X0, R1=Y0, R2=X1, R3=Y1.
; Сохраняет R5.
; ERASE_MODE проверяется один раз на линию, не на каждый пиксель.
; ---------------------------------------------------------------------
BRESENHAM:
        MOV     R5, -(SP)

        ; Вычисляем DELTA_X и знак STEP_X
        MOV     #1, STEP_X
        SUB     R0, R2          ; R2 = X1 - X0
        BGE     1$
        NEG     R2
        NEG     STEP_X
1$:
        MOV     R2, DELTA_X

        ; Вычисляем DELTA_Y и знаковый шаг по Y (Y_STRIDE: +64 или -64 байта)
        MOV     #100, Y_STRIDE  ; шаг на +1 строку вниз (+64 байта = 0100)
        SUB     R1, R3          ; R3 = Y1 - Y0
        BGE     2$
        NEG     R3
        NEG     Y_STRIDE        ; шаг на -1 строку вверх (-64 байта = -0100)
2$:
        MOV     R3, DELTA_Y

        ; Начальный адрес видеопамяти R4 = DRAW_BASE + Y0*64 + X0/4
        MOV     R1, R4
        SWAB    R4
        ASR     R4
        ASR     R4
        BIC     #140000, R4
        ADD     DRAW_BASE, R4

        MOV     R0, R3
        ASR     R3
        ASR     R3
        ADD     R3, R4

        ; Начальная 16-битная маска пикселя в R3 (значения: 3, 12., 48., 192.)
        MOV     R0, R3
        BIC     #177774, R3     ; R3 = X0 & 3
        ASL     R3
        MOV     PIX_MASKS_W(R3), R3

        ; R1 = знаковый Y_STRIDE (+100 или -100)
        MOV     Y_STRIDE, R1

        ; Сравнение ведущей координаты
        CMP     DELTA_X, DELTA_Y
        BLT     BRES_DY_INIT

; ---------------------------------------------------------------------
; Ведущая ось X (DELTA_X >= DELTA_Y)
; ---------------------------------------------------------------------
BRES_DX_INIT:
        MOV     DELTA_X, R5
        INC     R5              ; счетчик точек
        MOV     DELTA_X, R2
        ASR     R2              ; R2 = ошибка (DELTA_X / 2)
        MOV     DELTA_Y, R0     ; R0 = DELTA_Y для быстрого SUB R0, R2

        TST     ERASE_MODE
        BNE     BRES_DX_ERASE_SELECT

        TST     STEP_X
        BMI     BRES_DX_DRAW_NEG_LOOP

; --- DX DRAW POSITIVE (X шагает вправо: +1) ---
BRES_DX_DRAW_POS_LOOP:
        BISB    R3, (R4)
        SUB     R0, R2
        BGE     1$
        ADD     DELTA_X, R2
        ADD     R1, R4
1$:
        ASL     R3
        ASL     R3
        CMP     R3, #0400
        BLT     2$
        INC     R4
        MOV     #3, R3
2$:
        SOB     R5, BRES_DX_DRAW_POS_LOOP
        MOV     (SP)+, R5
        RTS     PC

; --- DX DRAW NEGATIVE (X шагает влево: -1) ---
BRES_DX_DRAW_NEG_LOOP:
        BISB    R3, (R4)
        SUB     R0, R2
        BGE     1$
        ADD     DELTA_X, R2
        ADD     R1, R4
1$:
        CMP     R3, #3
        BNE     2$
        DEC     R4
        MOV     #0300, R3
        BR      3$
2$:
        ASR     R3
        ASR     R3
3$:
        SOB     R5, BRES_DX_DRAW_NEG_LOOP
        MOV     (SP)+, R5
        RTS     PC

; --- Выбор режима стирания для DX ---
BRES_DX_ERASE_SELECT:
        TST     STEP_X
        BMI     BRES_DX_ERASE_NEG_LOOP

; --- DX ERASE POSITIVE (X шагает вправо: +1) ---
BRES_DX_ERASE_POS_LOOP:
        BICB    R3, (R4)
        SUB     R0, R2
        BGE     1$
        ADD     DELTA_X, R2
        ADD     R1, R4
1$:
        ASL     R3
        ASL     R3
        CMP     R3, #0400
        BLT     2$
        INC     R4
        MOV     #3, R3
2$:
        SOB     R5, BRES_DX_ERASE_POS_LOOP
        MOV     (SP)+, R5
        RTS     PC

; --- DX ERASE NEGATIVE (X шагает влево: -1) ---
BRES_DX_ERASE_NEG_LOOP:
        BICB    R3, (R4)
        SUB     R0, R2
        BGE     1$
        ADD     DELTA_X, R2
        ADD     R1, R4
1$:
        CMP     R3, #3
        BNE     2$
        DEC     R4
        MOV     #0300, R3
        BR      3$
2$:
        ASR     R3
        ASR     R3
3$:
        SOB     R5, BRES_DX_ERASE_NEG_LOOP
        MOV     (SP)+, R5
        RTS     PC


; ---------------------------------------------------------------------
; Ведущая ось Y (DELTA_Y > DELTA_X)
; ---------------------------------------------------------------------
BRES_DY_INIT:
        MOV     DELTA_Y, R5
        INC     R5              ; счетчик точек
        MOV     DELTA_Y, R2
        ASR     R2              ; R2 = ошибка (DELTA_Y / 2)
        MOV     DELTA_X, R0     ; R0 = DELTA_X для быстрого SUB R0, R2

        TST     ERASE_MODE
        BNE     BRES_DY_ERASE_SELECT

        TST     STEP_X
        BMI     BRES_DY_DRAW_NEG_LOOP

; --- DY DRAW POSITIVE (X шагает вправо: +1) ---
BRES_DY_DRAW_POS_LOOP:
        BISB    R3, (R4)
        ADD     R1, R4
        SUB     R0, R2
        BGE     2$
        ADD     DELTA_Y, R2
        ASL     R3
        ASL     R3
        CMP     R3, #0400
        BLT     2$
        INC     R4
        MOV     #3, R3
2$:
        SOB     R5, BRES_DY_DRAW_POS_LOOP
        MOV     (SP)+, R5
        RTS     PC

; --- DY DRAW NEGATIVE (X шагает влево: -1) ---
BRES_DY_DRAW_NEG_LOOP:
        BISB    R3, (R4)
        ADD     R1, R4
        SUB     R0, R2
        BGE     3$
        ADD     DELTA_Y, R2
        CMP     R3, #3
        BNE     1$
        DEC     R4
        MOV     #0300, R3
        BR      3$
1$:
        ASR     R3
        ASR     R3
3$:
        SOB     R5, BRES_DY_DRAW_NEG_LOOP
        MOV     (SP)+, R5
        RTS     PC

; --- Выбор режима стирания для DY ---
BRES_DY_ERASE_SELECT:
        TST     STEP_X
        BMI     BRES_DY_ERASE_NEG_LOOP

; --- DY ERASE POSITIVE (X шагает вправо: +1) ---
BRES_DY_ERASE_POS_LOOP:
        BICB    R3, (R4)
        ADD     R1, R4
        SUB     R0, R2
        BGE     2$
        ADD     DELTA_Y, R2
        ASL     R3
        ASL     R3
        CMP     R3, #0400
        BLT     2$
        INC     R4
        MOV     #3, R3
2$:
        SOB     R5, BRES_DY_ERASE_POS_LOOP
        MOV     (SP)+, R5
        RTS     PC

; --- DY ERASE NEGATIVE (X шагает влево: -1) ---
BRES_DY_ERASE_NEG_LOOP:
        BICB    R3, (R4)
        ADD     R1, R4
        SUB     R0, R2
        BGE     3$
        ADD     DELTA_Y, R2
        CMP     R3, #3
        BNE     1$
        DEC     R4
        MOV     #0300, R3
        BR      3$
1$:
        ASR     R3
        ASR     R3
3$:
        SOB     R5, BRES_DY_ERASE_NEG_LOOP

BRES_END:
        MOV     (SP)+, R5
        RTS     PC


; ---------------------------------------------------------------------
; UPDATE_FPS — измерение времени кадра и расчёт FPS.
;
; Таймер считает вниз с периодом около 32 мкс.
; 1 секунда ~= 31250 тиков.
;
; Выход:
;   FPS_TENS — десятки FPS.
;   FPS_ONES — единицы FPS.
;
; Диапазон отображения: 00..99.
; UDIV: R0 / R1 -> R0.
; ---------------------------------------------------------------------
UPDATE_FPS:
        ; Текущее значение таймера.
        MOV     @#177710, R0

        ; Предыдущее значение таймера.
        MOV     PREV_TIMER, R1

        ; Сохраняем текущее значение.
        MOV     R0, PREV_TIMER

        ; Количество тиков за кадр.
        SUB     R0, R1

        ; Сохраняем прошедшие тики таймера для отсчёта 10 секунд
        MOV     R1, FRAME_DELTA_TICKS

        ; Защита от деления на ноль.
        TST     R1
        BEQ     FPS_INVALID

        ; FPS = 31250 / количество тиков.
        MOV     #31250., R0
        JSR     PC, UDIV

        ; Ограничение диапазона 00..99.
        CMP     R0, #99.
        BLE     FPS_SPLIT
        MOV     #99., R0

FPS_SPLIT:
        ; Выделяем десятки.
        CLR     FPS_TENS

FPS_TENS_LOOP:
        CMP     R0, #10.
        BLT     FPS_ONES_STORE
        SUB     #10., R0
        INC     FPS_TENS
        BR      FPS_TENS_LOOP

FPS_ONES_STORE:
        MOV     R0, FPS_ONES
        RTS     PC

FPS_INVALID:
        CLR     FPS_TENS
        CLR     FPS_ONES
        RTS     PC


; ---------------------------------------------------------------------
; DRAW_FPS — вывод двух цифр FPS в правом верхнем углу.
;
; Цифры 8x8:
;   десятки: X=240, Y=2, смещение 58 байт;
;   единицы: X=248, Y=2, смещение 60 байта.
;
; DRAW_BASE — адрес начала текущей страницы.
; ---------------------------------------------------------------------
DRAW_FPS:
        ; Десятки: строка Y=2, X=240, смещение 186 байта (2*64 + 58).
        MOV     FPS_TENS, R0
        MOV     DRAW_BASE, R1
        ADD     #186., R1
        JSR     PC, DRAW_DIGIT

        ; Единицы: строка Y=2, X=248, смещение 188 байт (2*64 + 60).
        MOV     FPS_ONES, R0
        MOV     DRAW_BASE, R1
        ADD     #188., R1
        JSR     PC, DRAW_DIGIT

        RTS     PC


; ---------------------------------------------------------------------
; DRAW_DIGIT — вывод одной цифры 8x8.
;
; Экран: 256x256, 2 бита на пиксель.
;
; Вход:
;   R0 = номер цифры 0..9.
;   R1 = байтовый адрес начала цифры в видеопамяти.
;
; Один спрайт занимает 16 байт: 8 слов по 2 байта.
; Каждая строка спрайта — одно 16-битное слово.
; Шаг между строками экрана — 64 байта.
; ---------------------------------------------------------------------
DRAW_DIGIT:
        ; Адрес спрайта = DIGIT_FONT + номер * 16.
        ASL     R0
        ASL     R0
        ASL     R0
        ASL     R0
        ADD     #DIGIT_FONT, R0

        MOV     #8., R2

DRAW_DIGIT_ROW:
        ; Накладываем цветную маску на видеопамять.
        ; Нулевые пиксели прозрачны.
        BIS     (R0)+, (R1)

        ; Следующая строка экрана.
        ADD     #64., R1

        SOB     R2, DRAW_DIGIT_ROW
        RTS     PC


; ---------------------------------------------------------------------
; PROCESS_INPUT_TIMER
; Проверяет нажатие клавиши (пробел или любая другая) или истечение 10 сек.
; ---------------------------------------------------------------------
PROCESS_INPUT_TIMER:
        JSR     PC, CHECK_KEYPRESS
        BCS     SWITCH_NOW

        ; Накопление тиков таймера (31250 тиков ~= 1 сек)
        ADD     FRAME_DELTA_TICKS, TICK_ACCUM
        CMP     TICK_ACCUM, #31250.
        BLO     1$
        SUB     #31250., TICK_ACCUM
        INC     SECONDS_CTR
        CMP     SECONDS_CTR, #10.
        BLO     1$

SWITCH_NOW:
        JSR     PC, SWITCH_NEXT_SHIP
1$:
        RTS     PC


; ---------------------------------------------------------------------
; CHECK_KEYPRESS
; Опрос клавиатуры БК-0011М:
; - Регистр 177660 (бит 7: флаг готовности кода)
; - Регистр 177716 (бит 6: индикатор нажатия клавиши, 0=нажата)
; Возвращает C=1 при новом нажатии любой клавиши, C=0 если нет.
; Защита от автоповтора при удержании клавиши.
; ---------------------------------------------------------------------
CHECK_KEYPRESS:
        BIT     #200, @#177660
        BNE     1$
        BIT     #100, @#177716
        BEQ     1$

        ; Клавиша не нажата
        CLRB    KEY_WAS_PRESSED
        CLC
        RTS     PC

1$:
        ; Клавиша нажата - читаем код клавиши для сброса флага готовности
        MOV     @#177662, R0
        TSTB    KEY_WAS_PRESSED
        BNE     2$
        MOVB    #1, KEY_WAS_PRESSED
        SEC                             ; Новое нажатие (C=1)
        RTS     PC

2$:
        CLC                             ; Клавиша удерживается (C=0)
        RTS     PC


; ---------------------------------------------------------------------
; SWITCH_NEXT_SHIP
; Переключение на следующую модель корабля в кольцевом списке.
; ---------------------------------------------------------------------
SWITCH_NEXT_SHIP:
        CLR     TICK_ACCUM
        CLR     SECONDS_CTR

        INC     CUR_MODEL_IDX
        CMP     CUR_MODEL_IDX, #NUM_MODELS
        BLT     1$
        CLR     CUR_MODEL_IDX
1$:
        ; R0 = CUR_MODEL_IDX * 12
        MOV     CUR_MODEL_IDX, R0
        ASL     R0
        MOV     R0, R1
        ASL     R0
        ADD     R1, R0
        ASL     R0
        ADD     #SHIP_MODELS, R0

        MOV     (R0)+, CUR_VERTS
        MOV     (R0)+, CUR_EDGES
        MOV     (R0)+, CUR_NORMALS
        MOV     (R0)+, CUR_NUM_VERTS
        MOV     (R0)+, CUR_NUM_EDGES
        MOV     (R0)+, CUR_NUM_FACES

        RTS     PC


; ---------------------------------------------------------------------
; ДЕЛЕНИЕ НА 128 (СДВИГ НА 7 БИТ ВПРАВО)
; ---------------------------------------------------------------------
DIV128:
        ASL     R0
        SWAB    R0
        MOVB    R0, R0
        RTS     PC


; ---------------------------------------------------------------------
; БЫСТРОЕ ЗНАКОВОЕ УМНОЖЕНИЕ 8x8 БИТ (ТАБЛИЦА ЧЕТВЕРТЕЙ КВАДРАТОВ)
; A*B = Q[|A+B|] - Q[|A-B|], где Q[k] = k^2 / 4
; Вход: R1 = A (знаковый), R2 = B (знаковый)
; Выход: R0 = A * B (знаковое 16-бит)
; Повреждает R1. Сохраняет R2, R3, R4, R5. Без стека и без циклов.
; ---------------------------------------------------------------------
MUL8:
        MOV     R1, R0
        ADD     R2, R0
        BPL     1$
        NEG     R0
1$:
        ASL     R0
        MOV     SQR_TAB(R0), R0

        SUB     R2, R1
        BPL     2$
        NEG     R1
2$:
        ASL     R1
        SUB     SQR_TAB(R1), R0
        RTS     PC


; ---------------------------------------------------------------------
; БЫСТРОЕ 8-БИТНОЕ ДЕЛЕНИЕ ДЛЯ ПЕРСПЕКТИВНОЙ ПРОЕКЦИИ
; R0 = (|coord| * 256) / Z, где |coord| < Z, результат помещается в 8 бит.
; Вход: R0 = |coord| (0..127), R1 = Z (16..300)
; Выход: R0 = частное (0..255)
; Повреждает R1, R2, R4. Сохраняет R3, R5. Без использования стека.
; ---------------------------------------------------------------------
DIV_Z256:
        MOV     R0, R2          ; остаток R2 = |coord|
        CLR     R0              ; частное R0 = 0

        ; 8 полностью развернутых шагов без SOB и без счетчиков
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     1$
        SUB     R1, R2
        INC     R0
1$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     2$
        SUB     R1, R2
        INC     R0
2$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     3$
        SUB     R1, R2
        INC     R0
3$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     4$
        SUB     R1, R2
        INC     R0
4$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     5$
        SUB     R1, R2
        INC     R0
5$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     6$
        SUB     R1, R2
        INC     R0
6$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     7$
        SUB     R1, R2
        INC     R0
7$:
        ASL     R2
        ASL     R0
        CMP     R2, R1
        BLO     8$
        SUB     R1, R2
        INC     R0
8$:
        RTS     PC


; ---------------------------------------------------------------------
; ПРОГРАММНОЕ ДЕЛЕНИЕ 16/16 БИТ
; ---------------------------------------------------------------------
UDIV:
        CLR     -(SP)
        CLR     -(SP)
        INC     (SP)

        TST     R1
        BEQ     DIV_Z

D_LOOP:
        ASL     R0
        ROL     2(SP)
        CMP     2(SP), R1
        BLO     D_NEXT
        SUB     R1, 2(SP)
        SEC
        ROL     (SP)
        BCC     D_LOOP
        BR      D_DONE
D_NEXT:
        ASL     (SP)
        BCC     D_LOOP
D_DONE:
        MOV     (SP)+, R0
        TST     (SP)+
        RTS     PC

DIV_Z:
        MOV     #177777, R0
        TST     (SP)+
        TST     (SP)+
        RTS     PC


; ---------------------------------------------------------------------
; ДАННЫЕ И ТАБЛИЦЫ
; ---------------------------------------------------------------------

; Четвертый цвет палитры (маски цвета: 11b в каждом из 4 пикселей байта)
        .EVEN
PIX_MASKS_W:
        .WORD   0b00000011, 0b00001100, 0b00110000, 0b11000000

; ---------------------------------------------------------------------
; МОДЕЛИ КЛАССИЧЕСКИХ КОРАБЛЕЙ BBC MICRO ELITE
; ---------------------------------------------------------------------
        .INCLUDE "ships.inc"

; ---------------------------------------------------------------------
; ТАБЛИЦА ВСЕХ МОДЕЛЕЙ
; Формат каждой записи (12 байт):
;   +0: адрес вершин
;   +2: адрес рёбер
;   +4: адрес нормалей граней
;   +6: количество вершин
;   +8: количество рёбер
;  +10: количество граней
; ---------------------------------------------------------------------
        .EVEN
SHIP_MODELS:
        ; 0. Cobra Mk III
        .WORD   VERTS_COBRA, EDGES_COBRA, FACE_NORMALS_COBRA, 28., 38., 13.
        ; 1. Sidewinder
        .WORD   VERTS_SIDEWINDER, EDGES_SIDEWINDER, FACE_NORMALS_SIDEWINDER, 10., 15., 7.
        ; 2. Viper
        .WORD   VERTS_VIPER, EDGES_VIPER, FACE_NORMALS_VIPER, 15., 20., 7.
        ; 3. Mamba
        .WORD   VERTS_MAMBA, EDGES_MAMBA, FACE_NORMALS_MAMBA, 25., 28., 5.
        ; 4. Python
        ; .WORD   VERTS_PYTHON, EDGES_PYTHON, FACE_NORMALS_PYTHON, 11., 26., 13.
        ; 5. Thargoid
        ; .WORD   VERTS_THARGOID, EDGES_THARGOID, FACE_NORMALS_THARGOID, 20., 26., 10.
        ; 6. Coriolis
        ; .WORD   VERTS_CORIOLIS, EDGES_CORIOLIS, FACE_NORMALS_CORIOLIS, 16., 28., 14.
        ; 7. Missile
        .WORD   VERTS_MISSILE, EDGES_MISSILE, FACE_NORMALS_MISSILE, 17., 24., 9.
        ; 8. Asteroid
        ; .WORD   VERTS_ASTEROID, EDGES_ASTEROID, FACE_NORMALS_ASTEROID, 9., 21., 14.
        ; 9. Canister
        .WORD   VERTS_CANISTER, EDGES_CANISTER, FACE_NORMALS_CANISTER, 10., 15., 7.
        ; 10. Thargon
        .WORD   VERTS_THARGON, EDGES_THARGON, FACE_NORMALS_THARGON, 10., 15., 7.
        ; 11. Escape Pod
        .WORD   VERTS_ESCAPE_POD, EDGES_ESCAPE_POD, FACE_NORMALS_ESCAPE_POD, 4., 6., 4.

NUM_MODELS = 8.

        .EVEN
; Параметры текущей отображаемой модели
CUR_MODEL_IDX:  .WORD   0
CUR_VERTS:      .WORD   VERTS_COBRA
CUR_EDGES:      .WORD   EDGES_COBRA
CUR_NORMALS:    .WORD   FACE_NORMALS_COBRA
CUR_NUM_VERTS:  .WORD   28.
CUR_NUM_EDGES:  .WORD   38.
CUR_NUM_FACES:  .WORD   13.

; Переменные таймера и клавиатуры
FRAME_DELTA_TICKS: .WORD 0
TICK_ACCUM:     .WORD   0
SECONDS_CTR:    .WORD   0
KEY_WAS_PRESSED:.BYTE   0

        .EVEN
DRAW_BASE:      .WORD   040000
DISPLAY_VALUE:  .WORD   100000

; Переменные измерения FPS.
PREV_TIMER:     .WORD   0
FPS_TENS:       .WORD   0
FPS_ONES:       .WORD   0

        .EVEN
FACE_FLAGS:     .BLKB   16.
        .EVEN
FACE_CTR:       .WORD   0
TMP_NZ1:        .WORD   0
EDGE_FACE2:     .WORD   0

        .EVEN
; Временное хранение индексов вершин при формировании списка.
EDGE_V1:            .BYTE   0
EDGE_V2:            .BYTE   0

        .EVEN
; Количество рёбер, отобранных для текущего кадра.
VISIBLE_EDGE_COUNT: .WORD   0

; Максимум 40 рёбер по 2 байта на ребро.
VISIBLE_EDGES:      .BLKB   80.
        .EVEN
VERT_USED:          .BLKB   32.
OLD_PTR:            .WORD   0

        .EVEN
; Режим пиксельной операции:
; 0 = рисование, 1 = стирание.
ERASE_MODE: .WORD 0

; Сохранённые координаты рёбер страницы 5.
; Запись: X0, Y0, X1, Y1.
        .EVEN
OLD5_COUNT: .WORD 0
OLD5_LINES: .BLKB 160.

; Сохранённые координаты рёбер страницы 6.
        .EVEN
OLD6_COUNT: .WORD 0
OLD6_LINES: .BLKB 160.

        .EVEN
ANGLE_Y: .BYTE  0
ANGLE_X: .BYTE  0
SIN_Y:   .BYTE  0
COS_Y:   .BYTE  0
SIN_X:   .BYTE  0
COS_X:   .BYTE  0

        .EVEN
TMP_X1:  .WORD  0
TMP_Z1:  .WORD  0
TMP_Y2:  .WORD  0
TMP_Z2:  .WORD  0

LINE_X0: .BYTE  0
LINE_Y0: .BYTE  0
LINE_X1: .BYTE  0
LINE_Y1: .BYTE  0

        .EVEN
EDGE_CTR: .WORD 0
DELTA_X: .WORD  0
DELTA_Y: .WORD  0
STEP_X:  .WORD  0
STEP_Y:  .WORD  0
Y_STRIDE: .WORD 0

        .EVEN
PROJ_X: .BLKB   32.
PROJ_Y: .BLKB   32.

; ---------------------------------------------------------------------
; DIGIT_FONT — микроспрайты цифр 0..9, размер каждой 8x8.
;
; Каждая цифра занимает 8 слов (16 байт).
; Порядок: верхняя строка -> нижняя строка.
; ---------------------------------------------------------------------
        .EVEN
DIGIT_FONT:

; Цифра 0
        .WORD   005240, 024050, 120012, 120012
        .WORD   120012, 120012, 024050, 005240

; Цифра 1
        .WORD   001200, 001240, 001200, 001200
        .WORD   001200, 001200, 005240, 005240

; Цифра 2
        .WORD   005240, 024050, 024000, 005000
        .WORD   000240, 000050, 024050, 025250

; Цифра 3
        .WORD   005250, 024000, 024000, 005240
        .WORD   024000, 024000, 024050, 005240

; Цифра 4
        .WORD   005000, 005200, 005040, 005010
        .WORD   025250, 005000, 005000, 005000

; Цифра 5
        .WORD   025250, 000050, 000050, 005250
        .WORD   024000, 024000, 024050, 005240

; Цифра 6
        .WORD   005240, 000050, 000012, 005252
        .WORD   024012, 024012, 024050, 005240

; Цифра 7
        .WORD   025250, 024000, 005000, 001200
        .WORD   000240, 000240, 000240, 000240

; Цифра 8
        .WORD   005240, 024050, 024050, 005240
        .WORD   024050, 024050, 024050, 005240

; Цифра 9
        .WORD   005240, 024050, 024050, 025240
        .WORD   024000, 005000, 001200, 000240

        .EVEN
PROD_CTR:   .WORD 0

; Таблицы по 256 слов.
; Используются только индексы координат, присутствующих в модели.
        .EVEN
PROD_SINY:  .BLKW 256.
PROD_COSY:  .BLKW 256.
PROD_SINX:  .BLKW 256.
PROD_COSX:  .BLKW 256.

; ТАБЛИЦА ЧЕТВЕРТЕЙ КВАДРАТОВ (Для: БЫСТРОЕ ЗНАКОВОЕ УМНОЖЕНИЕ 8x8 БИТ)
        .EVEN
SQR_TAB: .BLKW  256.

; ГОТОВЫЕ ТАБЛИЦЫ (Для: ТРАНСФОРМАЦИЯ И ПРОЕКЦИЯ ВЕРШИН)
        .EVEN
SIN_TAB:
        .BYTE 0., 3., 6., 9., 12., 16., 19., 22., 25., 28., 31., 34., 37., 40., 43., 46.
        .BYTE 49., 51., 54., 57., 60., 63., 65., 68., 71., 73., 76., 78., 81., 83., 85., 88.
        .BYTE 90., 92., 94., 96., 98., 100., 102., 104., 106., 107., 109., 111., 112., 113., 115., 116.
        .BYTE 117., 118., 120., 121., 122., 122., 123., 124., 125., 125., 126., 126., 126., 127., 127., 127.
        .BYTE 127., 127., 127., 127., 126., 126., 126., 125., 125., 124., 123., 122., 122., 121., 120., 118.
        .BYTE 117., 116., 115., 113., 112., 111., 109., 107., 106., 104., 102., 100., 98., 96., 94., 92.
        .BYTE 90., 88., 85., 83., 81., 78., 76., 73., 71., 68., 65., 63., 60., 57., 54., 51.
        .BYTE 49., 46., 43., 40., 37., 34., 31., 28., 25., 22., 19., 16., 12., 9., 6., 3.
        .BYTE 0., -3., -6., -9., -12., -16., -19., -22., -25., -28., -31., -34., -37., -40., -43., -46.
        .BYTE -49., -51., -54., -57., -60., -63., -65., -68., -71., -73., -76., -78., -81., -83., -85., -88.
        .BYTE -90., -92., -94., -96., -98., -100., -102., -104., -106., -107., -109., -111., -112., -113., -115., -116.
        .BYTE -117., -118., -120., -121., -122., -122., -123., -124., -125., -125., -126., -126., -126., -127., -127., -127.
        .BYTE -127., -127., -127., -127., -126., -126., -126., -125., -125., -124., -123., -122., -122., -121., -120., -118.
        .BYTE -117., -116., -115., -113., -112., -111., -109., -107., -106., -104., -102., -100., -98., -96., -94., -92.
        .BYTE -90., -88., -85., -83., -81., -78., -76., -73., -71., -68., -65., -63., -60., -57., -54., -51.
        .BYTE -49., -46., -43., -40., -37., -34., -31., -28., -25., -22., -19., -16., -12., -9., -6., -3.


; ---------------------------------------------------------------------
; ДАННЫЕ ОРИГИНАЛЬНОЙ ЗАСТАВКИ ELITE
; ---------------------------------------------------------------------
        .EVEN
        .INCLUDE "cockpit.inc"

        .END    START
