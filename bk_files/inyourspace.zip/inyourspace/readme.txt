What's new in the final version:
- the demo size is 61 kb (was 76)
- the non-proportional font routine replaces plain bitmaps
- no sound clicks anymore
- the volume is increased a bit
- samples are stored in standard .wav format (was raw data)
- error handling (missing files, not wav format, etc.)
- duplicated drum samples were removed (now low-quality samples are calculated from high-quality ones)
- two new samples added

The first part works well on both BK0011M with floppy disk drive and ordinary BK0010.
You can even load it from an audio tape. To do this, record files on the tape in the following order:
 inyoursp.exe
 kick.wav
 kicksnar.wav
 hats.wav
 hat.wav
 solo.wav
 major.wav
 synth1.wav
 synth4.wav
 bass.wav

The second part works on BK0011M only. It can be run under MkDos or AnDos. No extended memory needed.

Check some useful tools we made during the development of this demo: www.thesands.ru/bk0010

P.S. guys, always make a final version of your scene release!
P.P.S. greets too all demosceners from Russia and around the world

www.demoscene.ru
www.youtube.com/matchugovsky