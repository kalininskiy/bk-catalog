"Good Apple (Bad Apple remix)" demo by the SandS.

Credits:
Ivanq - assembler code, JavaScript code, PDPy-11 compiler.
Manwe - assembler code, hardware research, design, animation.
Lasoft - hardware support, testing.
Anira - original black and white shadow art.
Masayoshi Minoshima - music.
Nomico - vocal.

August 2018.



This demo pushes the limits of BK-0011M hardware.
You can enjoy the demo in 3 ways:

1. on real hardware,
2. on emulator,
3. on YouTube (not recommended).



1. Real hardware

BK-0011M is the Soviet home computer released in
late 80s. It was a successor of a popular BK-0010
machine designed in 1983 and shipped to the mass
market in 1986. BK has marvelous 16 bit PDP-11
compatible architecture paired with very slow
dynamic memory. Fortunately, an external HDD
controller with additional fast static memory
was released by AltPro in the early 90s.

You need a standard BK-0011M running at 4 MHz,
equipped with Covox sound device and SMK-64 (or
higher) HDD controller. We recommend to use a
fast Compact Flash card instead of a mechanical
IDE hard drive.

To copy "Good Apple" to your BK hard drive do
the following:
- connect 2 HDDs (master and slave) to your BK,
- create two 32 Mb partitions on target HDD using
  SERVICE2 tool,
- run TWO_HDD driver for MK-DOS (check its readme),
- copy both partitions held by "Good Apple" demo
  from source HDD to target HDD using COPDEV util,
- you can copy files manually instead; if you do so
  run BootApple.exe on the target drive to make
  it bootable.

If you've downloaded "Good Apple" from the Internet:
- dump your BK HDD to the file using HDD Raw Copy
  or USB Image Tool for Windows,
- download BK emulator from gid.pdp-11.ru,
- convert your dumped image file to .hdi format
  using HDD ImgMaker tool from emulator's package,
- run the emulator with your .hdi file attached as
  master and "Good Apple" .hdi attached as slave,
- copy the demo as described above as if you use
  real hardware,
- close the emulator and convert your .hdi to .img
  using HDD ImgMaker tool from emulator package,
- burn .img back to your hard drive using HDD Raw
  Copy or USB Image Tool.



2. Emulator

- download BK emulator from gid.pdp-11.ru,
- run the emulator with "Good Apple" .hdi attached.



3. YouTube

- subscribe youtube.com/matchugovsky
- visit www.thesands.ru



Final version:

- more headphones
- more colors
- more greetings
- better sync (even better than original has)

2019 fixed version:

- tested on SMK-64, now works well



Known issues:

- The demo runs too slow on emulator, since it can
  not emulate the fast memory of SMK-64. Set 7 MHz
  to reach the proper speed.
- Credits part works properly on 4 MHz only. Don't
  forget to set the CPU speed back.



Make your own demos for BK-0010 and BK-0011M using
our new PDP-11 compiler: github.com/imachug/PDPy11

