; �������������������� ��������

;	mov #1330,@#177664
	mov (r7),r1
Cls:;	add (r1),@#RndEnum
	clr (r1)+
	tst r1
	bpl Cls

Loop:	mov #Sparks-377,r5	; elastic
0:	add #400,r5
	cmp #Sparks+2001,r5
;cmp #Sparks+401,r5
	beq Loop

	mov r5,r1
00:	jsr r5,@#Rnd	.word -40000
	bicb r1,40000(r0)
	asl r1
	bne 00

	mov r5,r1
	dec (r5)	; Mode (New/Do)
	bpl 1
	jsr r5,@#New	.word NewPos	; New
	swab -(r1)
	call @#NewColor
	br 0
1:	tst (r1)+
	clr r2
2:	movb (r1)+,r0	; a=X(Y)
	sub r0,(r1)+	; V
	movb -(r1),r0
	add r0,-(r1)	; X(Y)
	bisb (r1),r2	; Yx
	swab r2
	cmp (r1)+,(r1)+
	inc r7
	br 2

	add #100200-3407,r2	; Center
3:	mov r1,(r6)
4:	mov r1,r0
	mov (r0)+,r4	; C
	add (r0)+,(r0)	; V+=a
	bcc 5
	call @#NewColor
	br 3
5:	add (r0)+,(r0)	; Acc+=V
	bcc 6
	swab r4
6:	jsr r5,@#Rnd
Size=.	.word 170360
	add r2,r0
	clr r3
	sec
	ror r0
	rol r3
	ror r0
	rol r3
	movb PxMsk(r3),r3
	bicb r3,(r0)
	bicb r4,r3
	bisb r3,(r0)
	decb (r6)
	bpl 4
	br 0

NewColor:
	mov r5,r1
	add #13,r1
	jsr r5,@#New	.word NewCol
	mov -(r1),r0	; Color No in Accu
	beq NewColor
	sub #6,r1
	movb ColMsk(r0),(r1)
	swab (r1)
	ret
	
;New:	mov (r5)+,r4	; Cfg Addr
;	mov (r4)+,r3	; Cfg Mask
;0:	asl r3		; Const/End?
;	bne 1
;	rts r5
;1:	bcs 2
;	clr (r1)+	; Clear Field
;	br 0
;2:	mov (r4)+,@#NewMsk
;	jsr r5,@#Rnd	; Gen Value
;NewMsk=.	.word 0
;	asl r3		; Mod?
;	bcc 3
;	add (r4)+,r0	; Mod Value
;3:	mov r0,(r1)+
; 	br 0

New:	mov (r5)+,r4	; Cfg Addr
	mov (r4)+,r3	; Cfg Mask
0:	mov (r4)+,@#NewMsk
	beq 1
	jsr r5,@#Rnd	; Gen Value
NewMsk=.	.word 0
	add (r4)+,r0
1:	mov r0,(r1)+
	sob r3,0
	rts r5

Rnd:	mov @#RndEnum,r0	; jsr r5,@#Rnd, .word Mask
	asl r0
	bcs 0
	add #67353,r0
0:	swab r0
RndEnum	=.+2
	mov r0,#0
	bic (r5)+,r0
	rts r5

NewPos:	.word 5, -10000,10000, -40000,20000, -4000,-2000, 0, -40000,10000
; 176700, -4000,2000, -40000,20000, -2000,-1000,  -40000,40000	;11 11 11 0 11 1  Cnt=1024+Rnd(2048), X=8192+Rnd(16384), dx=Rnd(1024)-512, Y=0, dy=16384+Rnd(16384)
NewCol:	.word 3, -10,1, 0, -4,0
; 152000, -10,1,  -4	; 11 0 10 1	x, a=1+Rnd(8), V=0, Accu=ColNo
PxMsk:	.byte 3,60,14,300	; Pos: 0,2,1,3
ColMsk:	.byte 255.,252,125,0	; Clear Masks: Black,Blue,Green,Red

Var:
Sparks	=6000	;4x{ Cnt, X,V, Y,V, C(2db), St,Sp,Ac}
