Tape:

1. Disconnect HDD controller from your BK 0011M.
2. Connect audio cable to load from a sound source.
3. Turn on your computer, press quickly and hold Space key.
4. You are in Monitor. Press "L", that means "load".
5. After "Name?" prompt (in Russian) press Enter.
6. Play BoingBall.wav file from this archive (3 seconds long).
7. If everything is OK, you'll see file name and address.
8. Press "G", that means "go".
9. Watch the progress bar and then the intro itself.


Disk:

1. Download BKDE (BK Disk Explorer) from gid.pdp-11.ru
2. Open any BK floppy disk image with BKDE.
3. Drag and drop BoingBall.bin into BKDE window.
4. Close BKDE. Use that floppy disk image with emulator.
5. In emulator, copy BoingBall from the floppy to HDD image.
6. Close the emulators because it suxx on this intro.
7. Burn HDD image to Compact Flash or IDE HDD.
8. Watch the intro on the real hardware.