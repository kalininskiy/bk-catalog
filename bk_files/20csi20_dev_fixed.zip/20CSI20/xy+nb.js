FSO = WScript.CreateObject('Scripting.FileSystemObject');
File = FSO.GetFile('xysin.txt');
TextStream = File.OpenAsTextStream(1);
Result = '';
for(;!TextStream.AtEndOfStream;) {
    Result = Result + TextStream.ReadLine();
}
TextStream.Close();
xysinResult = Result.split(',');

File = FSO.GetFile('xycos.txt');
TextStream = File.OpenAsTextStream(1);
Result = '';
for(;!TextStream.AtEndOfStream;) {
    Result = Result + TextStream.ReadLine();
}
TextStream.Close();
xycosResult = Result.split(',');


File = FSO.GetFile('nb.txt');
TextStream = File.OpenAsTextStream(1);
Result = '';
for(;!TextStream.AtEndOfStream;) {
    Result = Result + TextStream.ReadLine();
}
TextStream.Close();
nbResult = Result.split(',');

outStr = 'ANIMBSIN:\r\n    .WORD\r\n';
strLen = 0;

for (i=0; i < xysinResult.length; i+=4) {
	gx = parseInt(xysinResult[i]) + 20;
	gy = parseInt(xysinResult[i+1]) + 14;
	outStr += gx + '.,' + gy + '.,' + nbResult[i/2] + ',';
	strLen += 10;
	if(strLen>80) {strLen = 0; outStr += '\r\n'}
}

outStr += '\r\n    -1\r\nANIMBCOS:\r\n    .WORD\r\n';
strLen = 0;

for (i=0; i < xycosResult.length; i+=4) {
	gx = parseInt(xycosResult[i]) + 20;
	gy = parseInt(xycosResult[i+1]) + 14;
	outStr += gx + '.,' + gy + '.,' + nbResult[i/2] + ',';
	strLen += 10;
	if(strLen>80) {strLen = 0; outStr += '\r\n'}
}
outStr += '\r\n    -1';


//WScript.echo(outStr);

TextStream = FSO.CreateTextFile('xynb.txt');
TextStream.Write(outStr);
TextStream.Close();

