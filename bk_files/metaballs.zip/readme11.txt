"metaballs11" was compiled to be loaded from tape to BK-0011(m).
Don't quit from Basic to Monitor. Instead, hold a key while reboot.
If you use MKDOS or AnDOS on your BK-0011(m), just run "metaballs".

The best BK-0010/11 emulator for Windows: gid.pdp-11.ru