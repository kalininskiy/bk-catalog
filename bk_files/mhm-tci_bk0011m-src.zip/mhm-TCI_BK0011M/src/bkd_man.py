# import numpy as np 
import sys
import os
from math import sqrt, ceil, floor
# from PIL import Image

def file_size(file_path):
    """
    this function will return the file size
    """
    if os.path.isfile(file_path):
        file_info = os.stat(file_path)
        return file_info.st_size
        
        
print('BRK disk manager v0.1')

n = len(sys.argv)
if n < 3 :
    print("Usage: bkd_man <source disk.img> <file.xyz> <target new disk.img>")
    sys.exit()

src_img = sys.argv[1] # 'watch.png'
file = sys.argv[2]
out = sys.argv[3]

#image = Image.open(img)
# p = image.getpalette()
# nc = int(len(p)/3)

fs = file_size(file) - 4

src = open(src_img, 'rb')
fil = open(file, 'rb')
f = open(out, 'wb')

cat = src.read( 0x2800 )
f.write(cat)

skip = src.read( fs )

skip_bin = fil.read( 4 )
bin = fil.read( fs )
f.write(bin)

rem = src.read( 829440 - fs - 0x2800 )
f.write(rem)

f.close()
src.close()

print(' '+ out + " - saved.")

