# import numpy as np 
import sys
import os
from math import sqrt, ceil, floor
from PIL import Image

print('TCI v0.1')
n = len(sys.argv)

if n < 2 :
    print("Usage: tci <image.png> [ 0,1,2,3 colors remap]")
    sys.exit()

remap = [0,1,2,3]
if n > 2 :
	remap[0] = int(sys.argv[2])
	remap[1] = int(sys.argv[3])
	remap[2] = int(sys.argv[4])
	remap[3] = int(sys.argv[5])
print(" remap- " + "".join([str(x) for x in remap]))

img = sys.argv[1] # 'watch.png'
out = img.replace("png", "bin", 1)

image = Image.open(img)
p = image.getpalette()
nc = int(len(p)/3)

im_w, im_h = image.size
clrs = image.getcolors()

print('Size: '+ str(im_w) +"x"+str(im_h)+ " " +str(nc)+ "c.")

f = open(out, 'wb')

pix = image.load()
for y in range(im_h):
	for x in range(0,im_w,4):
		c = (remap[pix[x+3,y]] * 64)
		c = c +(remap[pix[x+2,y]] * 16)
		c = c +(remap[pix[x+1,y]] * 4)
		c = c +(remap[pix[x+0,y]])
		f.write(c.to_bytes(1, byteorder='big'))


f.close()

print(' '+ out + " - saved.")

