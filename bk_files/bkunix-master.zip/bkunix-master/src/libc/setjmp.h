/*
 * Non-local jumps.
 *
 * This file is part of BKUNIX project, which is distributed
 * under the terms of the MIT License.
 * See the accompanying file "LICENSE" for more details.
 */
#ifndef _SETJMP_H_
#define _SETJMP_H_ 1

typedef int jmp_buf[3];

#endif /* _SETJMP_H_ */
