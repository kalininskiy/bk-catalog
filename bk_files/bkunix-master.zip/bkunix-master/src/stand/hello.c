int main ()
{
	puts ("Hello, World\n");
	return 0;
}
