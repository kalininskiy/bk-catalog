﻿"Flame512" INTRO IN 512 BYTES BY VLADIMIR 'KUVO' KUTYAKOV FROM CSI
(C) 2020
BK-0011 & BK-0010 RELEASE


Archive contains:

fl512_11.bin	- executable file for the BK-0011
fl512_10.bin	- executable file for the BK-0010

fl512_11.mac	- source assembly code (BK-0011 release)
fl512_10.mac	- source assembly code (BK-0010 release)

flametxt.raw	- gfx parts in source code
pal16grb.raw
pal16grrb.raw


